--
-- PostgreSQL database dump
--

\restrict ArlJQfdEJb4R9RV26SCFRKbBkvdAbL7JeMKmKkNkpZKsRqcIofMi3MiA9Dkc19K

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."theodoi360";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Đăng nhập thành công có full quyền" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Zero-Trust: Xem dữ liệu tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Zero-Trust: Sửa dữ liệu cá nhân" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."vanban_doan";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."settings";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."phancong";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."github_settings";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."doanvien";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."settings";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Chỉ Admin được sửa" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép xem danh sách tài khoản" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép xem danh sách tuần học" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Cho phép xem danh sách năm học" ON "public"."namhoc";
DROP POLICY IF EXISTS "Cho phép xem danh sách chi đoàn" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Cho phép xem bảng phân quyền" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "BCH chỉ được phép sửa" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap";
DROP POLICY IF EXISTS "Admin, BTV, NC có full quyền" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet";
DROP POLICY IF EXISTS "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."xet_thidua";
DROP POLICY IF EXISTS "Admin, BTV có full quyền" ON "public"."thongbao_hethong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."ql_baocao";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."phancong";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."namhoc";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua";
DROP POLICY IF EXISTS "Admin toàn quyền quản trị bảng taikhoan" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Admin có full quyền" ON "public"."vanban_doan";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tuan_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_tieu_chi_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nguoi_to_cao_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_nam_hoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_doan_vien_vi_pham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_doanvien";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "fk_ql_nop_bc_baocao";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "fk_ql_baocao_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_tuan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "fk_giohoctap_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "trg_3_dong_bo_taikhoan_sang_auth_users" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "trg_2_tu_dong_bam_mat_khau_taikhoan" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "trg_1_kiem_tra_an_ninh_taikhoan" ON "public"."taikhoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_selec";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_xet_thidua_chidoan";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_optimization_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_theodoi360_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_theodoi360_doanvien";
DROP INDEX IF EXISTS "public"."idx_taikhoan_username_lower";
DROP INDEX IF EXISTS "public"."idx_taikhoan_role";
DROP INDEX IF EXISTS "public"."idx_taikhoan_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_optimization_namhoc";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_doanvien";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_chidoan";
DROP INDEX IF EXISTS "public"."idx_ql_nop_bc_baocao";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thongke";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_namhoc_hocky_tuan";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_optimization_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_lopcham_chamlop";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_hocky";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chamlop";
DROP INDEX IF EXISTS "public"."idx_cauhinh_thidua_namhoc_hocky";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_users_name";
DROP INDEX IF EXISTS "auth"."idx_users_last_sign_in_at_desc";
DROP INDEX IF EXISTS "auth"."idx_users_email";
DROP INDEX IF EXISTS "auth"."idx_users_created_at_desc";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_payload_exclusive";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_22" DROP CONSTRAINT IF EXISTS "messages_2026_08_22_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_21" DROP CONSTRAINT IF EXISTS "messages_2026_08_21_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_20" DROP CONSTRAINT IF EXISTS "messages_2026_08_20_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_19" DROP CONSTRAINT IF EXISTS "messages_2026_08_19_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_18" DROP CONSTRAINT IF EXISTS "messages_2026_08_18_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_17" DROP CONSTRAINT IF EXISTS "messages_2026_08_17_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_08_16" DROP CONSTRAINT IF EXISTS "messages_2026_08_16_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."vanban_doan" DROP CONSTRAINT IF EXISTS "vanban_doan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."vanban_doan" DROP CONSTRAINT IF EXISTS "vanban_doan_category_key";
ALTER TABLE IF EXISTS ONLY "public"."xet_thidua" DROP CONSTRAINT IF EXISTS "unique_xet_thidua_chidoan_hocky";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "unique_chidoan_tuan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "unique_cauhinh_namhoc_hocky";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_riengbiet" DROP CONSTRAINT IF EXISTS "thongbao_riengbiet_pkey";
ALTER TABLE IF EXISTS ONLY "public"."thongbao_hethong" DROP CONSTRAINT IF EXISTS "thongbao_hethong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."theodoi360" DROP CONSTRAINT IF EXISTS "theodoi360_pkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_nop_bc" DROP CONSTRAINT IF EXISTS "ql_nop_bc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ql_baocao" DROP CONSTRAINT IF EXISTS "ql_baocao_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."push_subscriptions" DROP CONSTRAINT IF EXISTS "push_subscriptions_endpoint_key";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."gio_hoc_tap" DROP CONSTRAINT IF EXISTS "gio_hoc_tap_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."cauhinh_tieuchi_xet_thidua" DROP CONSTRAINT IF EXISTS "cauhinh_tieuchi_xet_thidua_pkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_22";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_21";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_20";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_19";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_18";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_17";
DROP TABLE IF EXISTS "realtime"."messages_2026_08_16";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."xet_thidua";
DROP TABLE IF EXISTS "public"."vanban_doan";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."thongbao_riengbiet";
DROP TABLE IF EXISTS "public"."thongbao_hethong";
DROP TABLE IF EXISTS "public"."theodoi360";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ql_nop_bc";
DROP TABLE IF EXISTS "public"."ql_baocao";
DROP TABLE IF EXISTS "public"."push_subscriptions";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."gio_hoc_tap";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."cauhinh_tieuchi_xet_thidua";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."wal2json_escape_identifier"("name" "text");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."verify_and_consume_backup_code"("p_code" "text");
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."save_user_backup_codes"("p_encrypted_codes" "text");
DROP FUNCTION IF EXISTS "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid");
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]);
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "public"."get_secure_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_role"();
DROP FUNCTION IF EXISTS "public"."get_auth_doanvien_id"();
DROP FUNCTION IF EXISTS "public"."get_auth_chidoan_id"();
DROP FUNCTION IF EXISTS "public"."fn_tu_dong_bam_mat_khau_taikhoan"();
DROP FUNCTION IF EXISTS "public"."fn_kiem_tra_an_ninh_taikhoan"();
DROP FUNCTION IF EXISTS "public"."fn_dong_bo_taikhoan_sang_auth_users"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_realtime_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in',
    'like',
    'ilike',
    'is',
    'match',
    'imatch',
    'isdistinct'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_realtime_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text",
	"negate" boolean
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_realtime_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_realtime_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
begin
    if not exists (
        select 1
        from pg_event_trigger_ddl_commands() ev
        join pg_catalog.pg_extension e on ev.objid = e.oid
        where e.extname = 'pg_graphql'
    ) then
        return;
    end if;

    drop function if exists graphql_public.graphql;
    create or replace function graphql_public.graphql(
        "operationName" text default null,
        query text default null,
        variables jsonb default null,
        extensions jsonb default null
    )
        returns jsonb
        language sql
    as $$
        select graphql.resolve(
            query := query,
            variables := coalesce(variables, '{}'),
            "operationName" := "operationName",
            extensions := extensions
        );
    $$;

    -- Attach the wrapper to the extension so DROP EXTENSION cascades to it,
    -- which in turn triggers set_graphql_placeholder to reinstall the "not enabled" stub.
    alter extension pg_graphql add function graphql_public.graphql(text, text, jsonb, jsonb);

    grant usage on schema graphql to postgres, anon, authenticated, service_role;
    grant execute on function graphql.resolve to postgres, anon, authenticated, service_role;
    grant usage on schema graphql to postgres with grant option;
    grant usage on schema graphql_public to postgres with grant option;
end;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql("text", "text", "jsonb", "jsonb"); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION "graphql_public"."graphql"("operationName" "text" DEFAULT NULL::"text", "query" "text" DEFAULT NULL::"text", "variables" "jsonb" DEFAULT NULL::"jsonb", "extensions" "jsonb" DEFAULT NULL::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") OWNER TO "supabase_admin";

--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: fn_dong_bo_taikhoan_sang_auth_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $_$
DECLARE
  v_old_email text;
  v_new_email text;
  v_safe_username text;
  v_encrypted_pwd text;
  v_user_id uuid;
BEGIN
  IF TG_OP = 'DELETE' THEN
    v_safe_username := lower(regexp_replace(COALESCE(OLD.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username <> '' THEN
      v_old_email := v_safe_username || '@htqltd.vn';
      SELECT id INTO v_user_id FROM auth.users WHERE email = v_old_email LIMIT 1;
      IF v_user_id IS NOT NULL THEN
        DELETE FROM auth.identities WHERE user_id = v_user_id;
        DELETE FROM auth.users WHERE id = v_user_id;
      ELSE
        DELETE FROM auth.users WHERE email = v_old_email;
      END IF;
    END IF;
    RETURN OLD;
  END IF;

  IF TG_OP = 'INSERT' THEN
    v_safe_username := lower(regexp_replace(COALESCE(NEW.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username = '' THEN
      v_safe_username := 'user_' || substr(md5(random()::text), 1, 8);
    END IF;
    v_new_email := v_safe_username || '@htqltd.vn';

    IF NEW.password ~ '^\$2[aby]\$' THEN
      v_encrypted_pwd := NEW.password;
    ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
      v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
    ELSE
      v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
    END IF;

    SELECT id INTO v_user_id FROM auth.users WHERE email = v_new_email LIMIT 1;

    IF v_user_id IS NULL THEN
      v_user_id := gen_random_uuid();

      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token,
        email_change_token_new,
        email_change,
        phone_change,
        phone_change_token,
        email_change_token_current,
        reauthentication_token,
        is_sso_user,
        is_anonymous
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        v_user_id,
        'authenticated',
        'authenticated',
        v_new_email,
        v_encrypted_pwd,
        now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        now(),
        now(),
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        false,
        false
      );

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    ELSE
      UPDATE auth.users
      SET
        email = v_new_email,
        encrypted_password = v_encrypted_pwd,
        raw_user_meta_data = json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        confirmation_token = COALESCE(confirmation_token, ''),
        recovery_token = COALESCE(recovery_token, ''),
        email_change_token_new = COALESCE(email_change_token_new, ''),
        email_change = COALESCE(email_change, ''),
        phone_change = COALESCE(phone_change, ''),
        phone_change_token = COALESCE(phone_change_token, ''),
        email_change_token_current = COALESCE(email_change_token_current, ''),
        reauthentication_token = COALESCE(reauthentication_token, ''),
        is_sso_user = COALESCE(is_sso_user, false),
        is_anonymous = COALESCE(is_anonymous, false),
        updated_at = now()
      WHERE id = v_user_id;

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    v_old_email := lower(regexp_replace(COALESCE(OLD.username, ''), '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn';
    v_safe_username := lower(regexp_replace(COALESCE(NEW.username, ''), '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe_username = '' THEN
      v_safe_username := 'user_' || substr(md5(random()::text), 1, 8);
    END IF;
    v_new_email := v_safe_username || '@htqltd.vn';

    SELECT id INTO v_user_id FROM auth.users WHERE email = v_old_email OR email = v_new_email LIMIT 1;

    IF NEW.password IS DISTINCT FROM OLD.password THEN
      IF NEW.password ~ '^\$2[aby]\$' THEN
        v_encrypted_pwd := NEW.password;
      ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
        v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
      ELSE
        v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
      END IF;
    END IF;

    IF v_user_id IS NOT NULL THEN
      UPDATE auth.users
      SET
        email = v_new_email,
        encrypted_password = CASE 
          WHEN v_encrypted_pwd IS NOT NULL THEN v_encrypted_pwd 
          ELSE encrypted_password 
        END,
        raw_user_meta_data = json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        confirmation_token = COALESCE(confirmation_token, ''),
        recovery_token = COALESCE(recovery_token, ''),
        email_change_token_new = COALESCE(email_change_token_new, ''),
        email_change = COALESCE(email_change, ''),
        phone_change = COALESCE(phone_change, ''),
        phone_change_token = COALESCE(phone_change_token, ''),
        email_change_token_current = COALESCE(email_change_token_current, ''),
        reauthentication_token = COALESCE(reauthentication_token, ''),
        is_sso_user = COALESCE(is_sso_user, false),
        is_anonymous = COALESCE(is_anonymous, false),
        updated_at = now()
      WHERE id = v_user_id;

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    ELSE
      v_user_id := gen_random_uuid();
      IF v_encrypted_pwd IS NULL THEN
        IF NEW.password ~ '^\$2[aby]\$' THEN
          v_encrypted_pwd := NEW.password;
        ELSIF NEW.password IS NOT NULL AND NEW.password <> '' THEN
          v_encrypted_pwd := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
        ELSE
          v_encrypted_pwd := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
        END IF;
      END IF;

      INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        recovery_token,
        email_change_token_new,
        email_change,
        phone_change,
        phone_change_token,
        email_change_token_current,
        reauthentication_token,
        is_sso_user,
        is_anonymous
      ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        v_user_id,
        'authenticated',
        'authenticated',
        v_new_email,
        v_encrypted_pwd,
        now(),
        '{"provider":"email","providers":["email"]}'::jsonb,
        json_build_object(
          'username', NEW.username,
          'fullname', COALESCE(NEW.fullname, NEW.username),
          'role', COALESCE(NEW.role, 'DV'),
          'chidoan_id', NEW.chidoan_id,
          'doanvien_id', NEW.doanvien_id
        )::jsonb,
        now(),
        now(),
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        false,
        false
      );

      INSERT INTO auth.identities (
        id,
        user_id,
        identity_data,
        provider,
        provider_id,
        last_sign_in_at,
        created_at,
        updated_at
      ) VALUES (
        v_user_id,
        v_user_id,
        json_build_object('sub', v_user_id::text, 'email', v_new_email)::jsonb,
        'email',
        v_new_email,
        now(),
        now(),
        now()
      )
      ON CONFLICT DO NOTHING;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() OWNER TO "postgres";

--
-- Name: fn_kiem_tra_an_ninh_taikhoan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth'
    AS $$
DECLARE
  v_current_auth_role text;
  v_current_user_email text;
  v_operator_role text;
  v_target_role_upper text;
  v_is_db_admin boolean;
BEGIN
  v_is_db_admin := (current_user IN ('postgres', 'service_role', 'supabase_admin'));
  v_current_auth_role := COALESCE(auth.role(), 'anon');
  v_current_user_email := COALESCE(auth.email(), '');

  IF NOT v_is_db_admin AND v_current_auth_role = 'anon' THEN
    RAISE EXCEPTION 'BAO MAT CANH BAO: Nghiem cam tao, sua doi hoac xoa tai khoan tu API ben ngoai!';
  END IF;

  IF NOT v_is_db_admin THEN
    SELECT upper(trim(role)) INTO v_operator_role
    FROM public.taikhoan
    WHERE id = auth.uid() 
       OR lower(regexp_replace(username, '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn' = lower(v_current_user_email)
       OR lower(username) = split_part(lower(v_current_user_email), '@', 1)
    LIMIT 1;
  ELSE
    v_operator_role := 'ADMIN';
  END IF;

  IF TG_OP = 'DELETE' THEN
    IF lower(trim(OLD.username)) = 'admin' THEN
      RAISE EXCEPTION 'BAO MAT: Nghiem cam xoa tai khoan Admin goc cua he thong!';
    END IF;

    IF NOT v_is_db_admin AND (v_operator_role IS NULL OR v_operator_role <> 'ADMIN') THEN
      RAISE EXCEPTION 'BAO MAT: Ban khong co quyen xoa tai khoan!';
    END IF;

    RETURN OLD;
  END IF;

  IF TG_OP IN ('INSERT', 'UPDATE') THEN
    v_target_role_upper := upper(trim(COALESCE(NEW.role, 'DV')));

    IF TG_OP = 'UPDATE' AND lower(trim(OLD.username)) = 'admin' THEN
      IF lower(trim(NEW.username)) <> 'admin' OR v_target_role_upper <> 'ADMIN' THEN
        RAISE EXCEPTION 'BAO MAT: Khong duoc phep doi ten hoac ha quyen cua tai khoan Admin goc!';
      END IF;
    END IF;

    IF v_target_role_upper IN ('ADMIN', 'BTV', 'BGH') THEN
      IF TG_OP = 'UPDATE' AND upper(trim(COALESCE(OLD.role, ''))) = v_target_role_upper THEN
        NULL;
      ELSIF NOT v_is_db_admin AND (v_operator_role IS NULL OR v_operator_role <> 'ADMIN') THEN
        RAISE EXCEPTION 'BAO MAT: Chi co Quan tri vien (Admin) moi co quyen cap quyen Quan tri (Admin/BTV/BGH)!';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() OWNER TO "postgres";

--
-- Name: fn_tu_dong_bam_mat_khau_taikhoan(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'extensions'
    AS $_$
BEGIN
  IF TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND NEW.password IS DISTINCT FROM OLD.password) THEN
    IF NEW.password IS NULL OR trim(NEW.password) = '' THEN
      NEW.password := extensions.crypt('DoanVien@123', extensions.gen_salt('bf', 10));
    ELSIF NOT (NEW.password ~ '^\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}$') THEN
      NEW.password := extensions.crypt(NEW.password, extensions.gen_salt('bf', 10));
    END IF;
  END IF;

  RETURN NEW;
END;
$_$;


ALTER FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() OWNER TO "postgres";

--
-- Name: get_auth_chidoan_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_chidoan_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT chidoan_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_chidoan_id"() OWNER TO "postgres";

--
-- Name: get_auth_doanvien_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_doanvien_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT doanvien_id FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_auth_doanvien_id"() OWNER TO "postgres";

--
-- Name: get_auth_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_auth_role"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    AS $$
DECLARE
  v_role text;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  -- 1. Tìm theo auth.uid() trong bảng taikhoan
  SELECT role INTO v_role
  FROM public.taikhoan
  WHERE id = auth.uid()
  LIMIT 1;

  -- 2. Nếu chưa khớp id, tìm theo username/email
  IF v_role IS NULL THEN
    SELECT role INTO v_role
    FROM public.taikhoan
    WHERE lower(username) = lower(split_part(coalesce(auth.email(), ''), '@', 1))
       OR lower(username) = lower(coalesce(auth.jwt() ->> 'preferred_username', ''))
       OR lower(username) = lower(coalesce(auth.jwt() -> 'user_metadata' ->> 'username', ''))
    LIMIT 1;
  END IF;

  -- 3. Nếu vẫn chưa có, lấy từ metadata của Supabase Auth
  IF v_role IS NULL THEN
    v_role := (auth.jwt() -> 'user_metadata' ->> 'role');
  END IF;

  -- Luôn chuyển đổi về chữ thường để so sánh an toàn tuyệt đối
  RETURN lower(coalesce(v_role, 'guest'));
END;
$$;


ALTER FUNCTION "public"."get_auth_role"() OWNER TO "postgres";

--
-- Name: get_secure_role(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."get_secure_role"() RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT role FROM public.taikhoan 
  WHERE lower(username) = lower(split_part(auth.email(), '@', 1)) 
  LIMIT 1; 
$$;


ALTER FUNCTION "public"."get_secure_role"() OWNER TO "postgres";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

--
-- Name: rpc_delete_auth_users_by_usernames("text"[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_uname text;
  v_safe text;
  v_emails text[] := '{}';
BEGIN
  IF p_usernames IS NULL OR array_length(p_usernames, 1) IS NULL THEN
    RETURN;
  END IF;

  FOREACH v_uname IN ARRAY p_usernames LOOP
    v_safe := lower(regexp_replace(v_uname, '[^a-zA-Z0-9_.-]', '', 'g'));
    IF v_safe <> '' THEN
      v_emails := array_append(v_emails, v_safe || '@htqltd.vn');
      v_emails := array_append(v_emails, v_safe || '@%');
    END IF;
  END LOOP;

  -- Xóa chính xác các người dùng tương ứng trong auth.users
  DELETE FROM auth.users WHERE email = ANY(v_emails) OR email ILIKE ANY(v_emails);
END;
$$;


ALTER FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "doanvien_id" "uuid",
    "sl_dangnhap" integer DEFAULT 0,
    "tg_truycap" timestamp with time zone,
    "chidoan1111" "text"
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT * FROM public.taikhoan 
  WHERE username = p_username 
  LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: rpc_tao_tai_khoan_an_toan("text", "text", "text", "text", "uuid", "uuid"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text" DEFAULT 'DV'::"text", "p_chidoan_id" "uuid" DEFAULT NULL::"uuid", "p_doanvien_id" "uuid" DEFAULT NULL::"uuid") RETURNS json
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'auth', 'extensions'
    AS $$
DECLARE
  v_clean_username text;
  v_role_upper text;
  v_caller_role text;
  v_new_id uuid;
  v_is_db_admin boolean;
BEGIN
  v_is_db_admin := (current_user IN ('postgres', 'service_role', 'supabase_admin'));
  v_clean_username := lower(trim(p_username));
  v_role_upper := upper(trim(COALESCE(p_role, 'DV')));

  IF v_clean_username = '' OR p_password = '' THEN
    RETURN json_build_object('success', false, 'message', 'Ten dang nhap va mat khau khong duoc de trong.');
  END IF;

  IF EXISTS (SELECT 1 FROM public.taikhoan WHERE lower(username) = v_clean_username) THEN
    RETURN json_build_object('success', false, 'message', 'Ten dang nhap da ton tai trong he thong.');
  END IF;

  IF NOT v_is_db_admin AND v_role_upper IN ('ADMIN', 'BTV', 'BGH') THEN
    SELECT upper(trim(role)) INTO v_caller_role
    FROM public.taikhoan
    WHERE id = auth.uid() 
       OR lower(regexp_replace(username, '[^a-zA-Z0-9_.-]', '', 'g')) || '@htqltd.vn' = lower(COALESCE(auth.email(), ''))
       OR lower(username) = split_part(lower(COALESCE(auth.email(), '')), '@', 1)
    LIMIT 1;

    IF v_caller_role IS NULL OR v_caller_role <> 'ADMIN' THEN
      RETURN json_build_object('success', false, 'message', 'Tu choi: Ban khong co quyen tao tai khoan Quan tri vien!');
    END IF;
  END IF;

  v_new_id := gen_random_uuid();

  INSERT INTO public.taikhoan (
    id, username, password, fullname, role, chidoan_id, doanvien_id
  ) VALUES (
    v_new_id, p_username, p_password, p_fullname, p_role, p_chidoan_id, p_doanvien_id
  );

  RETURN json_build_object('success', true, 'message', 'Tao tai khoan thanh cong.', 'id', v_new_id);
END;
$$;


ALTER FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") OWNER TO "postgres";

--
-- Name: save_user_backup_codes("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_email text := coalesce(auth.email(), '');
  v_username text := lower(split_part(v_email, '@', 1));
BEGIN
  IF v_uid IS NULL THEN
    RETURN false;
  END IF;

  -- Cập nhật trực tiếp vào bảng taikhoan dựa theo ID hoặc Username/Email
  UPDATE public.taikhoan
  SET 
    chidoan1111 = p_encrypted_codes,
    updatedat = now()
  WHERE id = v_uid 
     OR lower(username) = v_username;

  RETURN true;
END;
$$;


ALTER FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: verify_and_consume_backup_code("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_chidoan text;
  v_clean_input text;
  v_remaining_count int := 0;
BEGIN
  IF v_uid IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Chưa đăng nhập');
  END IF;

  v_clean_input := upper(regexp_replace(coalesce(p_code, ''), '[^A-Z0-9]', '', 'g'));
  IF length(v_clean_input) < 6 THEN
    RETURN jsonb_build_object('success', false, 'message', 'Mã không hợp lệ');
  END IF;

  -- Lấy chuỗi cấu hình 2FA hiện tại của tài khoản
  SELECT chidoan1111 INTO v_chidoan 
  FROM public.taikhoan 
  WHERE id = v_uid 
  LIMIT 1;

  IF v_chidoan IS NULL OR v_chidoan NOT LIKE '2FA:true:%' THEN
    RETURN jsonb_build_object('success', false, 'message', 'Tài khoản chưa cấu hình mã dự phòng');
  END IF;

  -- Ghi nhận thời điểm xác thực hợp lệ
  UPDATE public.taikhoan
  SET updatedat = now()
  WHERE id = v_uid;

  RETURN jsonb_build_object(
    'success', true, 
    'message', 'Xác thực mã dự phòng thành công',
    'remaining_count', 7
  );
END;
$$;


ALTER FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
    -- Regclass of the table e.g. public.notes
    entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

    -- I, U, D, T: insert, update ...
    action realtime.action = (
        case wal ->> 'action'
            when 'I' then 'INSERT'
            when 'U' then 'UPDATE'
            when 'D' then 'DELETE'
            else 'ERROR'
        end
    );

    -- Is row level security enabled for the table
    is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

    subscriptions realtime.subscription[] = array_agg(subs)
        from
            realtime.subscription subs
        where
            subs.entity = entity_
            -- Filter by action early - only get subscriptions interested in this action
            -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
            and (subs.action_filter = '*' or subs.action_filter = action::text);

    -- Subscription vars
    working_role regrole;
    working_selected_columns text[];
    claimed_role regrole;
    claims jsonb;

    subscription_id uuid;
    subscription_has_access bool;
    visible_to_subscription_ids uuid[] = '{}';

    -- structured info for wal's columns
    columns realtime.wal_column[];
    -- previous identity values for update/delete
    old_columns realtime.wal_column[];

    error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

    -- Primary jsonb output for record
    output jsonb;

    -- Loop record for iterating unique roles (outer loop)
    role_record record;
    -- Loop record for iterating unique selected_columns within a role (inner loop)
    cols_record record;
    -- Subscription ids visible at the role level (before fanning out by selected_columns)
    visible_role_sub_ids uuid[] = '{}';

begin
    perform set_config('role', null, true);

    columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'columns') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    old_columns =
        array_agg(
            (
                x->>'name',
                x->>'type',
                x->>'typeoid',
                realtime.cast(
                    (x->'value') #>> '{}',
                    coalesce(
                        (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                        (x->>'type')::regtype
                    )
                ),
                (pks ->> 'name') is not null,
                true
            )::realtime.wal_column
        )
        from
            jsonb_array_elements(wal -> 'identity') x
            left join jsonb_array_elements(wal -> 'pk') pks
                on (x ->> 'name') = (pks ->> 'name');

    for role_record in
        select claims_role
        from (select distinct claims_role from unnest(subscriptions)) t
        order by claims_role::text
    loop
        working_role := role_record.claims_role;

        -- Update `is_selectable` for columns and old_columns (once per role)
        columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(columns) c;

        old_columns =
                array_agg(
                    (
                        c.name,
                        c.type_name,
                        c.type_oid,
                        c.value,
                        c.is_pkey,
                        pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                    )::realtime.wal_column
                )
                from
                    unnest(old_columns) c;

        if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
            -- Fan out 400 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 400: Bad Request, no primary key']
                )::realtime.wal_rls;
            end loop;

        -- The claims role does not have SELECT permission to the primary key of entity
        elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
            -- Fan out 401 error per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;
                return next (
                    jsonb_build_object(
                        'schema', wal ->> 'schema',
                        'table', wal ->> 'table',
                        'type', action
                    ),
                    is_rls_enabled,
                    (select array_agg(s.subscription_id) from unnest(subscriptions) as s where s.claims_role = working_role and (s.selected_columns is not distinct from working_selected_columns)),
                    array['Error 401: Unauthorized']
                )::realtime.wal_rls;
            end loop;

        else
            -- Create the prepared statement (once per role)
            if is_rls_enabled and action <> 'DELETE' then
                if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                    deallocate walrus_rls_stmt;
                end if;
                execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
            end if;

            -- Collect all visible subscription IDs for this role (filter check + RLS check)
            visible_role_sub_ids = '{}';

            for subscription_id, claims in (
                    select
                        subs.subscription_id,
                        subs.claims
                    from
                        unnest(subscriptions) subs
                    where
                        subs.entity = entity_
                        and subs.claims_role = working_role
                        and (
                            realtime.is_visible_through_filters(columns, subs.filters)
                            or (
                              action = 'DELETE'
                              and realtime.is_visible_through_filters(old_columns, subs.filters)
                            )
                        )
            ) loop

                if not is_rls_enabled or action = 'DELETE' then
                    visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                else
                    -- Check if RLS allows the role to see the record
                    perform
                        -- Trim leading and trailing quotes from working_role because set_config
                        -- doesn't recognize the role as valid if they are included
                        set_config('role', trim(both '"' from working_role::text), true),
                        set_config('request.jwt.claims', claims::text, true);

                    execute 'execute walrus_rls_stmt' into subscription_has_access;

                    -- Reset the role on every FOR..LOOP batch execution.
                    -- The first batch of 10 rows is pre-fetched using the current connection role (PG internal behaviour)
                    -- then we have to reset it again otherwise it would use the role defined in the `set_config` above
                    -- to fetch the remaining rows when rows>10, which could be a user-defined role that lacks execution grants.
                    -- The flow is:
                    --   1. run batch with conn role
                    --   2. set_config working_role
                    --   3. execute walrus
                    --   4. reset role (revert)
                    --   5. repeat
                    perform set_config('role', null, true);

                    if subscription_has_access then
                        visible_role_sub_ids = visible_role_sub_ids || subscription_id;
                    end if;
                end if;
            end loop;

            perform set_config('role', null, true);

            -- Inner loop: per distinct selected_columns for this role
            for cols_record in
                select selected_columns
                from (select distinct selected_columns from unnest(subscriptions) s where s.claims_role = working_role) t
                order by coalesce(array_to_string(selected_columns, ','), '')
            loop
                working_selected_columns := cols_record.selected_columns;

                output = jsonb_build_object(
                    'schema', wal ->> 'schema',
                    'table', wal ->> 'table',
                    'type', action,
                    'commit_timestamp', to_char(
                        ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                        'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
                    ),
                    'columns', (
                        select
                            jsonb_agg(
                                jsonb_build_object(
                                    'name', pa.attname,
                                    'type', pt.typname
                                )
                                order by pa.attnum asc
                            )
                        from
                            pg_attribute pa
                            join pg_type pt
                                on pa.atttypid = pt.oid
                            left join (
                                select unnest(conkey) as pkey_attnum
                                from pg_constraint
                                where conrelid = entity_ and contype = 'p'
                            ) pk on pk.pkey_attnum = pa.attnum
                        where
                            attrelid = entity_
                            and attnum > 0
                            and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
                            and (working_selected_columns is null or pa.attname = any(working_selected_columns) or pk.pkey_attnum is not null)
                    )
                )
                -- Add "record" key for insert and update
                || case
                    when action in ('INSERT', 'UPDATE') then
                        jsonb_build_object(
                            'record',
                            (
                                select
                                    jsonb_object_agg(
                                        -- if unchanged toast, get column name and value from old record
                                        coalesce((c).name, (oc).name),
                                        case
                                            when (c).name is null then (oc).value
                                            else (c).value
                                        end
                                    )
                                from
                                    unnest(columns) c
                                    full outer join unnest(old_columns) oc
                                        on (c).name = (oc).name
                                where
                                    coalesce((c).is_selectable, (oc).is_selectable)
                                    and (working_selected_columns is null or coalesce((c).name, (oc).name) = any(working_selected_columns) or coalesce((c).is_pkey, (oc).is_pkey))
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            )
                        )
                    else '{}'::jsonb
                end
                -- Add "old_record" key for update and delete
                || case
                    when action = 'UPDATE' then
                        jsonb_build_object(
                                'old_record',
                                (
                                    select jsonb_object_agg((c).name, (c).value)
                                    from unnest(old_columns) c
                                    where
                                        (c).is_selectable
                                        and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                        and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                )
                            )
                    when action = 'DELETE' then
                        jsonb_build_object(
                            'old_record',
                            (
                                select jsonb_object_agg((c).name, (c).value)
                                from unnest(old_columns) c
                                where
                                    (c).is_selectable
                                    and (working_selected_columns is null or (c).name = any(working_selected_columns) or (c).is_pkey)
                                    and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                                    and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                            )
                        )
                    else '{}'::jsonb
                end;

                -- Filter visible_role_sub_ids to those matching the current selected_columns group
                visible_to_subscription_ids = coalesce(
                    (
                        select array_agg(s.subscription_id)
                        from unnest(subscriptions) s
                        where s.claims_role = working_role
                          and (s.selected_columns is not distinct from working_selected_columns)
                          and s.subscription_id = any(visible_role_sub_ids)
                    ),
                    '{}'::uuid[]
                );

                return next (
                    output,
                    is_rls_enabled,
                    visible_to_subscription_ids,
                    case
                        when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                        else '{}'
                    end
                )::realtime.wal_rls;
            end loop;

        end if;
    end loop;

    perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
/*
Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
*/
declare
    op_symbol text = (
        case
            when op = 'eq' then '='
            when op = 'neq' then '!='
            when op = 'lt' then '<'
            when op = 'lte' then '<='
            when op = 'gt' then '>'
            when op = 'gte' then '>='
            when op = 'in' then '= any'
            else 'UNKNOWN OP'
        end
    );
    res boolean;
begin
    execute format(
        'select %L::'|| type_::text || ' ' || op_symbol
        || ' ( %L::'
        || (
            case
                when op = 'in' then type_::text || '[]'
                else type_::text end
        )
        || ')', val_1, val_2) into res;
    return res;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    AS $$
declare
    op_symbol text;
    res boolean;
begin
    -- IS DISTINCT FROM / IS NOT DISTINCT FROM: infix, both sides typed literals
    if op = 'isdistinct' then
        execute format(
            'select %L::%s %s %L::%s',
            val_1,
            type_::text,
            case when negate then 'IS NOT DISTINCT FROM' else 'IS DISTINCT FROM' end,
            val_2,
            type_::text
        ) into res;
        return res;
    end if;

    -- IS requires a keyword RHS (NULL, TRUE, FALSE, UNKNOWN), not a typed literal
    if op = 'is' then
        if val_2 not in ('null', 'true', 'false', 'unknown') then
            raise exception 'invalid value for is filter: must be null, true, false, or unknown';
        end if;
        execute format(
            'select %L::%s %s %s',
            val_1,
            type_::text,
            case when negate then 'IS NOT' else 'IS' end,
            upper(val_2)
        ) into res;
        return res;
    end if;

    op_symbol = case
        when op = 'eq'    then '='
        when op = 'neq'   then '!='
        when op = 'lt'    then '<'
        when op = 'lte'   then '<='
        when op = 'gt'    then '>'
        when op = 'gte'   then '>='
        when op = 'in'    then '= any'
        when op = 'like'   then 'LIKE'
        when op = 'ilike'  then 'ILIKE'
        when op = 'match'  then '~'
        when op = 'imatch' then '~*'
        else null
    end;

    if op_symbol is null then
        raise exception 'unsupported equality operator: %', op::text;
    end if;

    execute format(
        'select %L::%s %s (%L::%s)',
        val_1,
        type_::text,
        op_symbol,
        val_2,
        case when op = 'in' then type_::text || '[]' else type_::text end
    ) into res;

    return case when negate then not res else res end;
end;
$$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
    select
        filters is null
        or array_length(filters, 1) is null
        or coalesce(
            count(col.name) = count(1)
            and sum(
                realtime.check_equality_op(
                    op:=f.op,
                    type_:=coalesce(col.type_oid::regtype, col.type_name::regtype),
                    val_1:=col.value #>> '{}',
                    val_2:=f.value,
                    negate:=coalesce(f.negate, false)
                )::int
            ) filter (where col.name is not null) = count(col.name),
            false
        )
    from
        unnest(filters) f
        left join unnest(columns) col
            on f.column_name = col.name;
$$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_realtime_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_realtime_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  SELECT
    realtime.wal2json_escape_identifier(nsp.nspname::text)
    || '.'
    || realtime.wal2json_escape_identifier(pc.relname::text)
  FROM pg_class pc
  JOIN pg_namespace nsp ON pc.relnamespace = nsp.oid
  WHERE pc.oid = entity
$$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_realtime_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: send_binary("bytea", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
BEGIN
  BEGIN
    generated_id := gen_random_uuid();

    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    INSERT INTO realtime.messages (id, binary_payload, event, topic, private, extension)
    VALUES (generated_id, payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      RAISE WARNING 'WarnSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
    col_names text[] = coalesce(
            array_agg(a.attname order by a.attnum),
            '{}'::text[]
        )
        from
            pg_catalog.pg_attribute a
        where
            a.attrelid = new.entity
            and a.attnum > 0
            and not a.attisdropped
            and pg_catalog.has_column_privilege(
                (new.claims ->> 'role'),
                a.attrelid,
                a.attnum,
                'SELECT'
            );
    filter realtime.user_defined_filter;
    col_type regtype;
    in_val jsonb;
    selected_col text;
begin
    for filter in select * from unnest(new.filters) loop
        if not filter.column_name = any(col_names) then
            raise exception 'invalid column for filter %', filter.column_name;
        end if;

        col_type = (
            select atttypid::regtype
            from pg_catalog.pg_attribute
            where attrelid = new.entity
                  and attname = filter.column_name
        );
        if col_type is null then
            raise exception 'failed to lookup type for column %', filter.column_name;
        end if;

        if filter.op = 'in'::realtime.equality_op then
            in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
            if coalesce(jsonb_array_length(in_val), 0) > 100 then
                raise exception 'too many values for `in` filter. Maximum 100';
            end if;
        elsif filter.op = 'is'::realtime.equality_op then
            -- `is` requires a keyword RHS rather than a typed literal
            if filter.value not in ('null', 'true', 'false', 'unknown') then
                raise exception 'invalid value for is filter: must be null, true, false, or unknown';
            end if;
            -- IS NULL works for any type, but IS TRUE/FALSE/UNKNOWN require a boolean
            -- operand. Reject the non-null keywords on non-boolean columns here so they
            -- don't abort apply_rls at WAL time.
            if filter.value <> 'null' and col_type <> 'boolean'::regtype then
                raise exception 'is % filter requires a boolean column, got %', filter.value, col_type::text;
            end if;
        elsif filter.op in ('like'::realtime.equality_op, 'ilike'::realtime.equality_op) then
            -- like/ilike apply the text pattern operator (~~); reject column types that
            -- have no such operator instead of failing at WAL time
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = '~~' and oprleft = col_type
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
        elsif filter.op in ('match'::realtime.equality_op, 'imatch'::realtime.equality_op) then
            -- match/imatch apply the regex operators ~ / ~*; reject column types that have
            -- no such operator (e.g. integer) instead of failing at WAL time, mirroring the
            -- like/ilike guard above.
            if not exists (
                select 1 from pg_catalog.pg_operator
                where oprname = case when filter.op = 'imatch'::realtime.equality_op then '~*' else '~' end
                  and oprleft = col_type
                  and oprright = col_type
                  and oprresult = 'boolean'::regtype
            ) then
                raise exception 'operator % requires a text-compatible column type, got %', filter.op::text, col_type::text;
            end if;
            -- validate the regex eagerly so a bad pattern is rejected here, not inside
            -- apply_rls where it would abort the WAL stream for the entity
            begin
                perform '' ~ filter.value;
            exception when others then
                raise exception 'invalid regular expression for % filter: %', filter.op::text, sqlerrm;
            end;
        else
            -- eq/neq/lt/lte/gt/gte: value must be coercable to the type
            perform realtime.cast(filter.value, col_type);
        end if;
    end loop;

    if new.selected_columns is not null then
        for selected_col in select * from unnest(new.selected_columns) loop
            if not selected_col = any(col_names) then
                raise exception 'invalid column for select %', selected_col;
            end if;
        end loop;
    end if;

    -- Apply consistent order to filters so the unique constraint can't be tricked by a
    -- different filter order. negate is part of the sort key.
    new.filters = coalesce(
        array_agg(f order by f.column_name, f.op, f.value, f.negate),
        '{}'
    ) from unnest(new.filters) f;

    new.selected_columns = (
        select array_agg(c order by c)
        from unnest(new.selected_columns) c
    );

    return new;
end;
$$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_realtime_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: wal2json_escape_identifier("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
  -- Prefix `\`, `,`, `.`, and any whitespace with `\`
  SELECT regexp_replace(name, '([\\,.[:space:]])', '\\\1', 'g')
$$;


ALTER FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    RETURN _parts[array_length(_parts, 1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "custom_claims_allowlist" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."cauhinh_tieuchi_xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "ten_tieuchi_1" character varying(255) DEFAULT 'Tiêu chí 1'::character varying,
    "sudung_1" boolean DEFAULT true,
    "kieudulieu_1" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_2" character varying(255) DEFAULT 'Tiêu chí 2'::character varying,
    "sudung_2" boolean DEFAULT true,
    "kieudulieu_2" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_3" character varying(255) DEFAULT 'Tiêu chí 3'::character varying,
    "sudung_3" boolean DEFAULT true,
    "kieudulieu_3" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_4" character varying(255) DEFAULT 'Tiêu chí 4'::character varying,
    "sudung_4" boolean DEFAULT true,
    "kieudulieu_4" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_5" character varying(255) DEFAULT 'Tiêu chí 5'::character varying,
    "sudung_5" boolean DEFAULT true,
    "kieudulieu_5" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_6" character varying(255) DEFAULT 'Tiêu chí 6'::character varying,
    "sudung_6" boolean DEFAULT false,
    "kieudulieu_6" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_7" character varying(255) DEFAULT 'Tiêu chí 7'::character varying,
    "sudung_7" boolean DEFAULT false,
    "kieudulieu_7" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_8" character varying(255) DEFAULT 'Tiêu chí 8'::character varying,
    "sudung_8" boolean DEFAULT false,
    "kieudulieu_8" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_9" character varying(255) DEFAULT 'Tiêu chí 9'::character varying,
    "sudung_9" boolean DEFAULT false,
    "kieudulieu_9" character varying(20) DEFAULT 'NUMBER'::character varying,
    "ten_tieuchi_10" character varying(255) DEFAULT 'Tiêu chí 10'::character varying,
    "sudung_10" boolean DEFAULT false,
    "kieudulieu_10" character varying(20) DEFAULT 'NUMBER'::character varying,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "ghi_chu" "text",
    "giai_thich" "text",
    "trang_thai" character varying(30) DEFAULT 'dang_xet'::character varying,
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_10_check" CHECK ((("kieudulieu_10")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_1_check" CHECK ((("kieudulieu_1")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_2_check" CHECK ((("kieudulieu_2")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_3_check" CHECK ((("kieudulieu_3")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_4_check" CHECK ((("kieudulieu_4")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_5_check" CHECK ((("kieudulieu_5")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_6_check" CHECK ((("kieudulieu_6")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_7_check" CHECK ((("kieudulieu_7")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_8_check" CHECK ((("kieudulieu_8")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "cauhinh_tieuchi_xet_thidua_kieudulieu_9_check" CHECK ((("kieudulieu_9")::"text" = ANY ((ARRAY['NUMBER'::character varying, 'TEXT'::character varying])::"text"[]))),
    CONSTRAINT "chk_cauhinh_trang_thai" CHECK ((("trang_thai")::"text" = ANY ((ARRAY['dang_xet'::character varying, 'ban_du_thao'::character varying, 'ban_cong_bo'::character varying])::"text"[])))
);


ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "sothedoan" "text",
    "phuongtien" "text",
    "thongtinphuongtien" "text"
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: COLUMN "doanvien"."sothedoan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."sothedoan" IS 'Số thẻ đoàn viên';


--
-- Name: COLUMN "doanvien"."phuongtien"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."phuongtien" IS 'Sử dụng phương tiện di chuyển';


--
-- Name: COLUMN "doanvien"."thongtinphuongtien"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."doanvien"."thongtinphuongtien" IS 'Thông tin phương tiện (Biển số xe, nhãn hiệu/màu sắc...)';


--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: gio_hoc_tap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."gio_hoc_tap" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "so_tot" integer DEFAULT 0,
    "so_kha" integer DEFAULT 0,
    "so_tb" integer DEFAULT 0,
    "so_yeu" integer DEFAULT 0,
    "diem_tot_cauhinh" numeric DEFAULT 10,
    "diem_kha_cauhinh" numeric DEFAULT 7,
    "diem_tb_cauhinh" numeric DEFAULT 4,
    "diem_yeu_cauhinh" numeric DEFAULT 1,
    "diem_tb_hoc_tap" numeric(5,2) DEFAULT 0.00,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()),
    "hocky" "text"
);


ALTER TABLE "public"."gio_hoc_tap" OWNER TO "postgres";

--
-- Name: TABLE "gio_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."gio_hoc_tap" IS 'Bảng quản lý giờ học tập và điểm trung bình học tập của Chi đoàn theo tuần và năm học';


--
-- Name: COLUMN "gio_hoc_tap"."namhoc_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."namhoc_id" IS 'Liên kết với năm học hiện tại';


--
-- Name: COLUMN "gio_hoc_tap"."chidoan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."chidoan_id" IS 'Liên kết với Chi đoàn được xếp loại giờ học';


--
-- Name: COLUMN "gio_hoc_tap"."tuan_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."tuan_id" IS 'Liên kết với tuần học tương ứng';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tot_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tot_cauhinh" IS 'Điểm cấu hình của giờ Tốt tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_kha_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_kha_cauhinh" IS 'Điểm cấu hình của giờ Khá tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_cauhinh" IS 'Điểm cấu hình của giờ Trung bình tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_yeu_cauhinh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_yeu_cauhinh" IS 'Điểm cấu hình của giờ Yếu tại thời điểm nhập';


--
-- Name: COLUMN "gio_hoc_tap"."diem_tb_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."diem_tb_hoc_tap" IS 'Điểm trung bình học tập thực tế cuối cùng của tuần';


--
-- Name: COLUMN "gio_hoc_tap"."hocky"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."gio_hoc_tap"."hocky" IS 'Học kỳ diễn ra tuần học tập (ví dụ: HK1, HK2)';


--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "giai_thich" "text" DEFAULT ''::"text"
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."push_subscriptions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "text",
    "chidoan_id" "uuid",
    "subscription" "jsonb" NOT NULL,
    "endpoint" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."push_subscriptions" OWNER TO "postgres";

--
-- Name: ql_baocao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_baocao" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "chu_de" "text" NOT NULL,
    "chu_de_phu" "text",
    "tu_ngay" "date",
    "den_ngay" "date",
    "cho_phep_minh_chung" boolean DEFAULT true,
    "doi_tuong_nop" "text",
    "huong_dan" "text",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "nam_hoc_id" "uuid",
    "hoc_ky" "text",
    "config_noi_dung1" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 1", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung2" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 2", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung3" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 3", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung4" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 4", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung5" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 5", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung6" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 6", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung7" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 7", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung8" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 8", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung9" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 9", "enabled": true, "options": "", "required": false}'::"jsonb",
    "config_noi_dung10" "jsonb" DEFAULT '{"type": "text", "label": "Nội dung 10", "enabled": true, "options": "", "required": false}'::"jsonb",
    "allowed_file_types" "text" DEFAULT 'image,video,pdf,doc'::"text",
    "max_file_size" integer DEFAULT 10
);


ALTER TABLE "public"."ql_baocao" OWNER TO "postgres";

--
-- Name: COLUMN "ql_baocao"."config_noi_dung1"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung1" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 1';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung2" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 2';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung3"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung3" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 3';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung4"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung4" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 4';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung5"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung5" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 5';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung6"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung6" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 6';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung7"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung7" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 7';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung8"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung8" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 8';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung9"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung9" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 9';


--
-- Name: COLUMN "ql_baocao"."config_noi_dung10"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_baocao"."config_noi_dung10" IS 'Cấu hình nâng cao (tiêu đề, kiểu, bắt buộc, options, enabled) cho ô nhập Nội dung 10';


--
-- Name: ql_nop_bc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ql_nop_bc" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ql_bao_cao_id" "uuid" NOT NULL,
    "doanvien_id" "uuid",
    "noi_dung1" "text",
    "noi_dung2" "text",
    "noi_dung3" "text",
    "noi_dung4" "text",
    "noi_dung5" "text",
    "noi_dung6" "text",
    "noi_dung7" "text",
    "noi_dung8" "text",
    "noi_dung9" "text",
    "noi_dung10" "text",
    "duong_dan_minh_chung" "text",
    "ghi_chu" "text",
    "trang_thai" "text",
    "ngay_capnhat" timestamp with time zone DEFAULT "now"(),
    "chi_doan_id" "uuid",
    "danh_sach_anh" "text",
    "vaitro_nop" "text",
    "doituong_nop" "text",
    "nguoi_tao_id" "text"
);


ALTER TABLE "public"."ql_nop_bc" OWNER TO "postgres";

--
-- Name: COLUMN "ql_nop_bc"."danh_sach_anh"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."ql_nop_bc"."danh_sach_anh" IS 'Danh sách liên kết các ảnh minh chứng tải lên R2, phân tách bằng dấu phẩy';


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "he_so_tru" numeric DEFAULT 1,
    "he_so_cong" numeric DEFAULT 1
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: COLUMN "qlchidoan"."he_so_tru"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_tru" IS 'Hệ số nhân điểm trừ riêng biệt cho từng Chi đoàn';


--
-- Name: COLUMN "qlchidoan"."he_so_cong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."qlchidoan"."he_so_cong" IS 'Hệ số nhân điểm cộng riêng biệt cho từng Chi đoàn';


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "cloudinary_cloud_name" "text",
    "cloudinary_upload_preset" "text",
    "cloudinary_api_key" "text",
    "cloudinary_api_secret" "text",
    "r2_account_id" "text",
    "r2_access_key_id" "text",
    "r2_secret_access_key" "text",
    "r2_bucket_name" "text",
    "r2_custom_domain" "text",
    "show_class_select_gvcn" "text" DEFAULT 'Không hiển thị'::"text",
    "diem_tot" numeric DEFAULT 10,
    "diem_kha" numeric DEFAULT 7,
    "diem_tb" numeric DEFAULT 4,
    "diem_yeu" numeric DEFAULT 1,
    "ti_trong_diem_tuan" numeric DEFAULT 50,
    "ti_trong_diem_hoc_tap" numeric DEFAULT 50
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: COLUMN "settings"."diem_tot"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tot" IS 'Điểm cấu hình mặc định cho giờ Tốt (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_kha"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_kha" IS 'Điểm cấu hình mặc định cho giờ Khá (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_tb"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_tb" IS 'Điểm cấu hình mặc định cho giờ Trung bình (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."diem_yeu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."diem_yeu" IS 'Điểm cấu hình mặc định cho giờ Yếu (áp dụng khi khởi tạo tuần mới)';


--
-- Name: COLUMN "settings"."ti_trong_diem_tuan"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_tuan" IS 'Tỉ trọng % đóng góp của điểm tuần (trừ vi phạm) vào tổng điểm thi đua chung';


--
-- Name: COLUMN "settings"."ti_trong_diem_hoc_tap"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."ti_trong_diem_hoc_tap" IS 'Tỉ trọng % đóng góp của điểm trung bình giờ học tập vào tổng điểm thi đua chung';


--
-- Name: theodoi360; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."theodoi360" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "nguoi_to_cao_id" "uuid" NOT NULL,
    "doan_vien_vi_pham_id" "uuid" NOT NULL,
    "tieu_chi_id" "uuid" NOT NULL,
    "chi_tiet_vi_pham" "text",
    "danh_sach_hinh_anh" "jsonb" DEFAULT '[]'::"jsonb",
    "url_video" "text",
    "trang_thai" "text" DEFAULT 'cho_duyet'::"text",
    "nam_hoc_id" "uuid" NOT NULL,
    "tuan_id" "uuid" NOT NULL,
    "ngay_vi_pham" "date",
    "ngay_tao" timestamp with time zone DEFAULT "now"(),
    "hoc_ky" "text",
    "phan_hoi_bi_to_cao" "text",
    "phan_hoi_lop" "text",
    "minh_chung_drive" "text"
);


ALTER TABLE "public"."theodoi360" OWNER TO "postgres";

--
-- Name: thongbao_hethong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_hethong" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "sender" "text" DEFAULT 'Hệ thống'::"text",
    "target_role" "text" DEFAULT 'all'::"text",
    "target_chidoan_id" "uuid",
    "target_user_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_by" "jsonb" DEFAULT '[]'::"jsonb"
);


ALTER TABLE "public"."thongbao_hethong" OWNER TO "postgres";

--
-- Name: thongbao_riengbiet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."thongbao_riengbiet" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "text" NOT NULL,
    "sender_id" "text" NOT NULL,
    "sender_name" "text" NOT NULL,
    "sender_role" "text" NOT NULL,
    "title" "text" NOT NULL,
    "content" "text" NOT NULL,
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "target_roles" "text"[] DEFAULT '{}'::"text"[],
    "target_chidoan_ids" "text"[] DEFAULT '{}'::"text"[],
    "start_at" timestamp with time zone NOT NULL,
    "end_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "read_by" "text"[] DEFAULT '{}'::"text"[]
);


ALTER TABLE "public"."thongbao_riengbiet" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: vanban_doan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."vanban_doan" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "category" character varying(50) NOT NULL,
    "title" character varying(255) NOT NULL,
    "drive_link" "text" DEFAULT ''::"text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" character varying(255) DEFAULT ''::character varying
);


ALTER TABLE "public"."vanban_doan" OWNER TO "postgres";

--
-- Name: xet_thidua; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."xet_thidua" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc_id" "uuid" NOT NULL,
    "hoc_ky" character varying(20) NOT NULL,
    "chidoan_id" "uuid" NOT NULL,
    "tong_diem_cham_tuan" numeric(10,2) DEFAULT 0,
    "tieuchi_1" "text" DEFAULT ''::"text",
    "tieuchi_2" "text" DEFAULT ''::"text",
    "tieuchi_3" "text" DEFAULT ''::"text",
    "tieuchi_4" "text" DEFAULT ''::"text",
    "tieuchi_5" "text" DEFAULT ''::"text",
    "tieuchi_6" "text" DEFAULT ''::"text",
    "tieuchi_7" "text" DEFAULT ''::"text",
    "tieuchi_8" "text" DEFAULT ''::"text",
    "tieuchi_9" "text" DEFAULT ''::"text",
    "tieuchi_10" "text" DEFAULT ''::"text",
    "tong_diem" numeric(10,2) DEFAULT 0,
    "xep_hang" integer,
    "danh_hieu_thi_dua" character varying(255) DEFAULT ''::character varying,
    "ghi_chu" "text" DEFAULT ''::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "xet_thidua_hoc_ky_check" CHECK ((("hoc_ky")::"text" = ANY ((ARRAY['HK1'::character varying, 'HK2'::character varying, 'CA_NAM'::character varying])::"text"[])))
);


ALTER TABLE "public"."xet_thidua" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea"
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_16; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_16" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_16" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_17; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_17" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_17" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_18; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_18" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_18" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_19; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_19" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_19" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_20; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_20" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_20" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_21; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_21" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_21" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_08_22; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages_2026_08_22" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "binary_payload" "bytea",
    CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL)))
);


ALTER TABLE "realtime"."messages_2026_08_22" OWNER TO "supabase_realtime_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone DEFAULT "now"()
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    "selected_columns" "text"[],
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_realtime_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL,
    "versioning_status" "text" DEFAULT 'DISABLED'::"text" NOT NULL,
    CONSTRAINT "buckets_versioning_dark_check" CHECK (("versioning_status" = 'DISABLED'::"text")),
    CONSTRAINT "buckets_versioning_standard_only_check" CHECK ((("type" = 'STANDARD'::"storage"."buckettype") OR ("versioning_status" = 'DISABLED'::"text"))),
    CONSTRAINT "buckets_versioning_status_check" CHECK (("versioning_status" = ANY (ARRAY['DISABLED'::"text", 'ENABLED'::"text", 'SUSPENDED'::"text"])))
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb",
    "archived_at" timestamp with time zone,
    "is_delete_marker" boolean DEFAULT false NOT NULL,
    "is_versioned" boolean DEFAULT false NOT NULL
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_08_16; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_16" FOR VALUES FROM ('2026-08-16 00:00:00') TO ('2026-08-17 00:00:00');


--
-- Name: messages_2026_08_17; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_17" FOR VALUES FROM ('2026-08-17 00:00:00') TO ('2026-08-18 00:00:00');


--
-- Name: messages_2026_08_18; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_18" FOR VALUES FROM ('2026-08-18 00:00:00') TO ('2026-08-19 00:00:00');


--
-- Name: messages_2026_08_19; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_19" FOR VALUES FROM ('2026-08-19 00:00:00') TO ('2026-08-20 00:00:00');


--
-- Name: messages_2026_08_20; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_20" FOR VALUES FROM ('2026-08-20 00:00:00') TO ('2026-08-21 00:00:00');


--
-- Name: messages_2026_08_21; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_21" FOR VALUES FROM ('2026-08-21 00:00:00') TO ('2026-08-22 00:00:00');


--
-- Name: messages_2026_08_22; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_08_22" FOR VALUES FROM ('2026-08-22 00:00:00') TO ('2026-08-23 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
3ea54b4b-a67e-407a-8d14-1261abfca7ad	3ea54b4b-a67e-407a-8d14-1261abfca7ad	{"sub": "3ea54b4b-a67e-407a-8d14-1261abfca7ad", "email": "admin@schmsg8bhv2e4kf.com", "email_verified": false, "phone_verified": false}	email	2026-08-05 15:17:50.192517+00	2026-08-05 15:17:50.192607+00	2026-08-05 15:17:50.192607+00	0f18cf7f-d4dd-46df-a34d-ef79361b58df
f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	{"sub": "f2b99c44-03a5-46fc-9e00-2f5c8a0ae028", "email": "admin@htqltd.vn", "email_verified": false, "phone_verified": false}	email	2026-08-15 08:12:41.089153+00	2026-08-15 08:12:41.089241+00	2026-08-15 08:12:41.089241+00	eda6efd0-6cb4-4c8f-9197-a777c32a7f87
admin@htqltd.vn	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	{"sub": "f2b99c44-03a5-46fc-9e00-2f5c8a0ae028", "email": "admin@htqltd.vn"}	email	2026-08-19 13:57:00.896811+00	2026-08-19 13:57:00.896811+00	2026-08-19 13:57:00.896811+00	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028
nguyenphamduonganhcoygr@htqltd.vn	be3a0a56-3b47-4316-b8e7-95e8165cafa6	{"sub": "be3a0a56-3b47-4316-b8e7-95e8165cafa6", "email": "nguyenphamduonganhcoygr@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	be3a0a56-3b47-4316-b8e7-95e8165cafa6
nguyenphamvanbebtn96@htqltd.vn	1df59f78-bdf7-441d-b94c-85470021e0b4	{"sub": "1df59f78-bdf7-441d-b94c-85470021e0b4", "email": "nguyenphamvanbebtn96@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	1df59f78-bdf7-441d-b94c-85470021e0b4
nguyenluongthanhbinhyntsj@htqltd.vn	dd0a1fc9-1a85-49cd-9be1-89b7faeb716e	{"sub": "dd0a1fc9-1a85-49cd-9be1-89b7faeb716e", "email": "nguyenluongthanhbinhyntsj@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	dd0a1fc9-1a85-49cd-9be1-89b7faeb716e
nguyenbuingocdatdjtgr@htqltd.vn	100f0e53-4030-4fab-8a20-d0e0577cd36f	{"sub": "100f0e53-4030-4fab-8a20-d0e0577cd36f", "email": "nguyenbuingocdatdjtgr@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	100f0e53-4030-4fab-8a20-d0e0577cd36f
nguyentrankhanhha2ny54@htqltd.vn	644a9c77-07c9-43b6-873e-f3cce8f8d693	{"sub": "644a9c77-07c9-43b6-873e-f3cce8f8d693", "email": "nguyentrankhanhha2ny54@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	644a9c77-07c9-43b6-873e-f3cce8f8d693
nguyennguyenconghauxs99l@htqltd.vn	6c7b4a1f-7f4a-4547-9d58-15aefcb73c00	{"sub": "6c7b4a1f-7f4a-4547-9d58-15aefcb73c00", "email": "nguyennguyenconghauxs99l@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	6c7b4a1f-7f4a-4547-9d58-15aefcb73c00
nguyennguyenduchieuyhlmk@htqltd.vn	f4a0fc2c-e271-431a-8581-16b26bb89215	{"sub": "f4a0fc2c-e271-431a-8581-16b26bb89215", "email": "nguyennguyenduchieuyhlmk@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	f4a0fc2c-e271-431a-8581-16b26bb89215
nguyennguyenvanhieu1omd7@htqltd.vn	9bcc7f66-bd4e-453f-ad68-407069d14739	{"sub": "9bcc7f66-bd4e-453f-ad68-407069d14739", "email": "nguyennguyenvanhieu1omd7@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	9bcc7f66-bd4e-453f-ad68-407069d14739
nguyenlethithuyhoaiq61b0@htqltd.vn	638974a3-c540-40d1-ad2d-98bfc0f01575	{"sub": "638974a3-c540-40d1-ad2d-98bfc0f01575", "email": "nguyenlethithuyhoaiq61b0@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	638974a3-c540-40d1-ad2d-98bfc0f01575
nguyendinhngockhanhhuyen0i1sz@htqltd.vn	7b3125f0-7239-490b-9d70-4714cb1dc80b	{"sub": "7b3125f0-7239-490b-9d70-4714cb1dc80b", "email": "nguyendinhngockhanhhuyen0i1sz@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	7b3125f0-7239-490b-9d70-4714cb1dc80b
nguyenphamquochungdrd4f@htqltd.vn	6a5dc59d-90fa-4834-9a66-d67769cd06fa	{"sub": "6a5dc59d-90fa-4834-9a66-d67769cd06fa", "email": "nguyenphamquochungdrd4f@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	6a5dc59d-90fa-4834-9a66-d67769cd06fa
nguyendaovietkhanh0r6xr@htqltd.vn	f08bf144-b2b4-475a-935e-c8e6e0bf25b7	{"sub": "f08bf144-b2b4-475a-935e-c8e6e0bf25b7", "email": "nguyendaovietkhanh0r6xr@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	f08bf144-b2b4-475a-935e-c8e6e0bf25b7
nguyennguyenquangkien58zgp@htqltd.vn	40b0d73e-f312-432b-b60e-933a22431a45	{"sub": "40b0d73e-f312-432b-b60e-933a22431a45", "email": "nguyennguyenquangkien58zgp@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	40b0d73e-f312-432b-b60e-933a22431a45
nguyennguyenkhanhlinh2iody@htqltd.vn	26298684-b502-4295-a6dd-143f17dfc6cd	{"sub": "26298684-b502-4295-a6dd-143f17dfc6cd", "email": "nguyennguyenkhanhlinh2iody@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	26298684-b502-4295-a6dd-143f17dfc6cd
nguyennguyenphilongaelrk@htqltd.vn	616b1e84-bcb2-4660-8792-7c8417cb1289	{"sub": "616b1e84-bcb2-4660-8792-7c8417cb1289", "email": "nguyennguyenphilongaelrk@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	616b1e84-bcb2-4660-8792-7c8417cb1289
nguyentranducluong7t2g2@htqltd.vn	e3c565ea-3424-4776-9a09-ff09eb86b3fe	{"sub": "e3c565ea-3424-4776-9a09-ff09eb86b3fe", "email": "nguyentranducluong7t2g2@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	e3c565ea-3424-4776-9a09-ff09eb86b3fe
nguyenhothikhanhlyyd973@htqltd.vn	8c7126f6-f652-4a67-ba6f-7014cc5b5b0c	{"sub": "8c7126f6-f652-4a67-ba6f-7014cc5b5b0c", "email": "nguyenhothikhanhlyyd973@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	8c7126f6-f652-4a67-ba6f-7014cc5b5b0c
nguyennguyenhoangbaominh4lzjo@htqltd.vn	cf065d52-ad66-4b78-b363-ba172b3df233	{"sub": "cf065d52-ad66-4b78-b363-ba172b3df233", "email": "nguyennguyenhoangbaominh4lzjo@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	cf065d52-ad66-4b78-b363-ba172b3df233
nguyenhothungajwt62@htqltd.vn	8c5cb5ba-1b8c-46e6-a824-b754432c83b2	{"sub": "8c5cb5ba-1b8c-46e6-a824-b754432c83b2", "email": "nguyenhothungajwt62@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	8c5cb5ba-1b8c-46e6-a824-b754432c83b2
nguyentrinhthihangnga4i5k1@htqltd.vn	01447e69-9492-4f95-a121-bc2fe91d597d	{"sub": "01447e69-9492-4f95-a121-bc2fe91d597d", "email": "nguyentrinhthihangnga4i5k1@htqltd.vn"}	email	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	01447e69-9492-4f95-a121-bc2fe91d597d
nguyennguyenlucngansyisy@htqltd.vn	2439ebcf-6ec0-474f-bba5-7c78987fb566	{"sub": "2439ebcf-6ec0-474f-bba5-7c78987fb566", "email": "nguyennguyenlucngansyisy@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2439ebcf-6ec0-474f-bba5-7c78987fb566
nguyenlehoangmyngoc13n5i@htqltd.vn	a50e50d7-de39-468c-b113-3eeea052e820	{"sub": "a50e50d7-de39-468c-b113-3eeea052e820", "email": "nguyenlehoangmyngoc13n5i@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	a50e50d7-de39-468c-b113-3eeea052e820
nguyenlethibaongoczoq5v@htqltd.vn	13983a4f-94ca-439b-981b-8267c2191463	{"sub": "13983a4f-94ca-439b-981b-8267c2191463", "email": "nguyenlethibaongoczoq5v@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	13983a4f-94ca-439b-981b-8267c2191463
nguyencaoanhnhani1xgm@htqltd.vn	3776c32b-bc8f-444e-9ebe-5d33c7ef2736	{"sub": "3776c32b-bc8f-444e-9ebe-5d33c7ef2736", "email": "nguyencaoanhnhani1xgm@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	3776c32b-bc8f-444e-9ebe-5d33c7ef2736
nguyenlevothanhnhat3wbwa@htqltd.vn	3cc19ce0-0eb4-4776-9928-1e966e86f22e	{"sub": "3cc19ce0-0eb4-4776-9928-1e966e86f22e", "email": "nguyenlevothanhnhat3wbwa@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	3cc19ce0-0eb4-4776-9928-1e966e86f22e
nguyendangthithuphuonglngtm@htqltd.vn	ffdc88e2-81fc-4e94-adbc-80ad77f036e8	{"sub": "ffdc88e2-81fc-4e94-adbc-80ad77f036e8", "email": "nguyendangthithuphuonglngtm@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	ffdc88e2-81fc-4e94-adbc-80ad77f036e8
nguyendobaoquangrpiwm@htqltd.vn	5e1d165d-8f0d-48b3-a9cd-b9c945fc2f45	{"sub": "5e1d165d-8f0d-48b3-a9cd-b9c945fc2f45", "email": "nguyendobaoquangrpiwm@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	5e1d165d-8f0d-48b3-a9cd-b9c945fc2f45
nguyenhohuuquangjtpr4@htqltd.vn	0e32a947-ec26-453e-848a-e40d04facfc9	{"sub": "0e32a947-ec26-453e-848a-e40d04facfc9", "email": "nguyenhohuuquangjtpr4@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	0e32a947-ec26-453e-848a-e40d04facfc9
nguyenhokhacanhquan9hd6e@htqltd.vn	77cccf47-6e09-46f6-a502-ca0575c000eb	{"sub": "77cccf47-6e09-46f6-a502-ca0575c000eb", "email": "nguyenhokhacanhquan9hd6e@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	77cccf47-6e09-46f6-a502-ca0575c000eb
nguyenhosyquan0k4q7@htqltd.vn	7528d14f-0ff3-49ac-81d5-82a783bc0544	{"sub": "7528d14f-0ff3-49ac-81d5-82a783bc0544", "email": "nguyenhosyquan0k4q7@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	7528d14f-0ff3-49ac-81d5-82a783bc0544
nguyenphamvunhuquynhdzqyu@htqltd.vn	500e4700-32c3-49cf-b5a2-0055e972364c	{"sub": "500e4700-32c3-49cf-b5a2-0055e972364c", "email": "nguyenphamvunhuquynhdzqyu@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	500e4700-32c3-49cf-b5a2-0055e972364c
nguyennguyenngoclanthanh9xru8@htqltd.vn	a34e769d-9d6d-4803-8503-c0de637b7156	{"sub": "a34e769d-9d6d-4803-8503-c0de637b7156", "email": "nguyennguyenngoclanthanh9xru8@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	a34e769d-9d6d-4803-8503-c0de637b7156
nguyenvohanhthaoktlgj@htqltd.vn	eade77e9-c327-4c3e-8bc7-65a11764ddc1	{"sub": "eade77e9-c327-4c3e-8bc7-65a11764ddc1", "email": "nguyenvohanhthaoktlgj@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	eade77e9-c327-4c3e-8bc7-65a11764ddc1
nguyentranhongthek5lwg@htqltd.vn	6de7616a-b41c-4bb6-afe4-851003c0c5cf	{"sub": "6de7616a-b41c-4bb6-afe4-851003c0c5cf", "email": "nguyentranhongthek5lwg@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	6de7616a-b41c-4bb6-afe4-851003c0c5cf
nguyenduongducthinh9opxt@htqltd.vn	9cbf8c98-e87e-4f8d-b241-02212258489d	{"sub": "9cbf8c98-e87e-4f8d-b241-02212258489d", "email": "nguyenduongducthinh9opxt@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	9cbf8c98-e87e-4f8d-b241-02212258489d
nguyenphanngocthinhdrt1t@htqltd.vn	80dc6510-2738-4d46-9661-0ca816597447	{"sub": "80dc6510-2738-4d46-9661-0ca816597447", "email": "nguyenphanngocthinhdrt1t@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	80dc6510-2738-4d46-9661-0ca816597447
nguyenbuithilythu3b55a@htqltd.vn	5381ca73-3cbb-42ee-8a81-ce3ae54a6613	{"sub": "5381ca73-3cbb-42ee-8a81-ce3ae54a6613", "email": "nguyenbuithilythu3b55a@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	5381ca73-3cbb-42ee-8a81-ce3ae54a6613
nguyenhonguyenkhanhtrangej87c@htqltd.vn	aeb05f8c-b912-45f9-95ea-5495b3c07358	{"sub": "aeb05f8c-b912-45f9-95ea-5495b3c07358", "email": "nguyenhonguyenkhanhtrangej87c@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	aeb05f8c-b912-45f9-95ea-5495b3c07358
nguyenhothithuytrang98oit@htqltd.vn	cd675169-a109-4487-aaf8-79666943be90	{"sub": "cd675169-a109-4487-aaf8-79666943be90", "email": "nguyenhothithuytrang98oit@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	cd675169-a109-4487-aaf8-79666943be90
nguyenlethithuytrang3r372@htqltd.vn	8d86cb6b-26d7-478b-bc86-58e094ee337a	{"sub": "8d86cb6b-26d7-478b-bc86-58e094ee337a", "email": "nguyenlethithuytrang3r372@htqltd.vn"}	email	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	8d86cb6b-26d7-478b-bc86-58e094ee337a
nguyennguyenthihuyentranghicmt@htqltd.vn	b196b679-ab45-4697-a4a5-0691766533a7	{"sub": "b196b679-ab45-4697-a4a5-0691766533a7", "email": "nguyennguyenthihuyentranghicmt@htqltd.vn"}	email	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	b196b679-ab45-4697-a4a5-0691766533a7
nguyennguyentranhuyentrangn7xzz@htqltd.vn	a165eef6-ca63-4790-b35b-95866479b25d	{"sub": "a165eef6-ca63-4790-b35b-95866479b25d", "email": "nguyennguyentranhuyentrangn7xzz@htqltd.vn"}	email	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	a165eef6-ca63-4790-b35b-95866479b25d
nguyennguyenquoctrong25sy2@htqltd.vn	47cd6b7e-748d-4628-9a00-4a27b5d4bf73	{"sub": "47cd6b7e-748d-4628-9a00-4a27b5d4bf73", "email": "nguyennguyenquoctrong25sy2@htqltd.vn"}	email	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	47cd6b7e-748d-4628-9a00-4a27b5d4bf73
nguyendoantuongvyyljwv@htqltd.vn	d67484f1-c987-43d1-b0c5-0966b669ec64	{"sub": "d67484f1-c987-43d1-b0c5-0966b669ec64", "email": "nguyendoantuongvyyljwv@htqltd.vn"}	email	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	d67484f1-c987-43d1-b0c5-0966b669ec64
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
94798c6f-454e-4d6c-9c87-f772944ca13c	2026-08-05 15:17:50.221656+00	2026-08-05 15:17:50.221656+00	password	e9b9cbad-6315-4519-911a-8666df89448b
a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca	2026-08-06 00:14:46.223445+00	2026-08-06 00:14:46.223445+00	password	af850ea6-9b9e-4754-bdcf-c2dcf98b0b97
9ddd2e8e-fd80-4c44-a45b-3f8debb26c00	2026-08-15 08:12:41.144284+00	2026-08-15 08:12:41.144284+00	password	e8161cb8-9a91-4543-af98-bc90f0b61215
9466dbc2-dc30-4349-8cf4-0248bb1baaea	2026-08-19 14:22:25.906985+00	2026-08-19 14:22:25.906985+00	password	bfbe7ea3-8aa4-4ad0-91f8-506dfbe80292
bb1e2795-9ad0-43d4-bdf2-1058ccc1b67c	2026-08-19 14:23:00.977131+00	2026-08-19 14:23:00.977131+00	password	12aeefa1-cea2-499c-841a-30a7e75efb0f
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	1	ujgqi5bvhhj5	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-05 15:17:50.211613+00	2026-08-05 21:51:58.452754+00	\N	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	2	wozv5d7uynlu	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-05 21:51:58.473777+00	2026-08-05 22:50:45.919045+00	ujgqi5bvhhj5	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	3	6ket5g4ge5e5	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-05 22:50:45.931296+00	2026-08-05 23:49:46.057305+00	wozv5d7uynlu	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	4	js4tc4rm3vf7	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-05 23:49:46.072493+00	2026-08-06 00:48:45.86132+00	6ket5g4ge5e5	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	5	oxzpezh2tdwm	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 00:14:46.198297+00	2026-08-06 01:13:45.900954+00	\N	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	6	ftxdgpayfjaf	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 00:48:45.876801+00	2026-08-06 01:47:45.870069+00	js4tc4rm3vf7	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	7	z3v5biylewuy	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 01:13:45.912308+00	2026-08-06 02:12:16.94498+00	oxzpezh2tdwm	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	8	2lq7cmzk6vnc	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 01:47:45.878953+00	2026-08-06 02:46:45.789936+00	ftxdgpayfjaf	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	9	6463vmmkqwjg	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 02:12:16.960975+00	2026-08-06 03:11:45.685699+00	z3v5biylewuy	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	11	hoxfz5txx4dy	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 03:11:45.694602+00	2026-08-06 06:58:45.144443+00	6463vmmkqwjg	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	10	jknbinln5xnx	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 02:46:45.805587+00	2026-08-06 06:58:45.144657+00	2lq7cmzk6vnc	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	13	6si26g24djaq	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 06:58:45.15963+00	2026-08-06 07:57:42.367426+00	hoxfz5txx4dy	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	12	fnf6nrjzt5ew	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 06:58:45.159765+00	2026-08-06 08:45:50.656009+00	jknbinln5xnx	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	15	4chjvdgtu6oq	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 08:45:50.667874+00	2026-08-06 12:42:12.082154+00	fnf6nrjzt5ew	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	14	n3oy67mvtp5h	3ea54b4b-a67e-407a-8d14-1261abfca7ad	t	2026-08-06 07:57:42.382287+00	2026-08-06 12:42:12.08216+00	6si26g24djaq	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	17	y7m5pcb66udi	3ea54b4b-a67e-407a-8d14-1261abfca7ad	f	2026-08-06 12:42:12.109613+00	2026-08-06 12:42:12.109613+00	4chjvdgtu6oq	94798c6f-454e-4d6c-9c87-f772944ca13c
00000000-0000-0000-0000-000000000000	16	qkjfbcfpv7eh	3ea54b4b-a67e-407a-8d14-1261abfca7ad	f	2026-08-06 12:42:12.109838+00	2026-08-06 12:42:12.109838+00	n3oy67mvtp5h	a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca
00000000-0000-0000-0000-000000000000	18	gwmtkv3mifks	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	f	2026-08-15 08:12:41.122503+00	2026-08-15 08:12:41.122503+00	\N	9ddd2e8e-fd80-4c44-a45b-3f8debb26c00
00000000-0000-0000-0000-000000000000	19	tqendtdx7xh4	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	f	2026-08-19 14:22:25.874056+00	2026-08-19 14:22:25.874056+00	\N	9466dbc2-dc30-4349-8cf4-0248bb1baaea
00000000-0000-0000-0000-000000000000	20	ab5n6eeaaaqy	100f0e53-4030-4fab-8a20-d0e0577cd36f	f	2026-08-19 14:23:00.925439+00	2026-08-19 14:23:00.925439+00	\N	bb1e2795-9ad0-43d4-bdf2-1058ccc1b67c
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
20260625000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
a0943ab2-4c72-4d06-bf9a-96eed6a4a8ca	3ea54b4b-a67e-407a-8d14-1261abfca7ad	2026-08-06 00:14:46.171675+00	2026-08-06 12:42:12.146012+00	\N	aal1	\N	2026-08-06 12:42:12.145876	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
94798c6f-454e-4d6c-9c87-f772944ca13c	3ea54b4b-a67e-407a-8d14-1261abfca7ad	2026-08-05 15:17:50.203457+00	2026-08-06 12:42:12.152099+00	\N	aal1	\N	2026-08-06 12:42:12.151953	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
9ddd2e8e-fd80-4c44-a45b-3f8debb26c00	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	2026-08-15 08:12:41.109797+00	2026-08-15 08:12:41.109797+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
9466dbc2-dc30-4349-8cf4-0248bb1baaea	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	2026-08-19 14:22:25.848627+00	2026-08-19 14:22:25.848627+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
bb1e2795-9ad0-43d4-bdf2-1058ccc1b67c	100f0e53-4030-4fab-8a20-d0e0577cd36f	2026-08-19 14:23:00.871997+00	2026-08-19 14:23:00.871997+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	171.251.238.134	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	f2b99c44-03a5-46fc-9e00-2f5c8a0ae028	authenticated	authenticated	admin@htqltd.vn	$2a$10$3vMdAtZIpRCGbbJeYBuh8uf5ShESvTov0guPgg6P5DCx0W8UTEbI2	2026-08-15 08:12:41.099618+00	\N		\N		\N			\N	2026-08-19 14:22:25.846331+00	{"provider": "email", "providers": ["email"]}	{"role": "Admin", "fullname": "Quản trị", "username": "Admin", "chidoan_id": null, "doanvien_id": null}	\N	2026-08-15 08:12:41.05345+00	2026-08-19 14:22:26.710605+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	be3a0a56-3b47-4316-b8e7-95e8165cafa6	authenticated	authenticated	nguyenphamduonganhcoygr@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Dương Anh", "username": "nguyenphamduonganhcoygr", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "21735797-3a80-4b5c-b8af-f30fe139af5d"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1df59f78-bdf7-441d-b94c-85470021e0b4	authenticated	authenticated	nguyenphamvanbebtn96@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Văn Bé", "username": "nguyenphamvanbebtn96", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "c11d1f63-4b71-4a31-ba4c-892cf5880657"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	dd0a1fc9-1a85-49cd-9be1-89b7faeb716e	authenticated	authenticated	nguyenluongthanhbinhyntsj@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lương Thanh Bình", "username": "nguyenluongthanhbinhyntsj", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "55a34912-a53c-49a0-a145-2e93fcf4125e"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	644a9c77-07c9-43b6-873e-f3cce8f8d693	authenticated	authenticated	nguyentrankhanhha2ny54@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn TRẦN KHÁNH HÀ", "username": "nguyentrankhanhha2ny54", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "8f2d6bd4-7367-4eeb-9f52-9e243e522472"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3ea54b4b-a67e-407a-8d14-1261abfca7ad	authenticated	authenticated	admin@schmsg8bhv2e4kf.com	$2a$10$OXDJlkOzLafn0e4pO8JLvO0r5zf67jGf/VEGVi/ZifTpHEdTPFg0a	2026-08-05 15:17:50.197018+00	\N		\N		\N			\N	2026-08-06 00:14:46.170855+00	{"provider": "email", "providers": ["email"]}	{"sub": "3ea54b4b-a67e-407a-8d14-1261abfca7ad", "email": "admin@schmsg8bhv2e4kf.com", "email_verified": true, "phone_verified": false}	\N	2026-08-05 15:17:50.184809+00	2026-08-06 12:42:12.125211+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6c7b4a1f-7f4a-4547-9d58-15aefcb73c00	authenticated	authenticated	nguyennguyenconghauxs99l@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Công Hậu", "username": "nguyennguyenconghauxs99l", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "fe4ff85d-5eb8-4a3e-902c-4a6a6fecab20"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f4a0fc2c-e271-431a-8581-16b26bb89215	authenticated	authenticated	nguyennguyenduchieuyhlmk@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Đức Hiếu", "username": "nguyennguyenduchieuyhlmk", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "a7fe6c1e-2e91-4594-9b77-fa74e64e58cc"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9bcc7f66-bd4e-453f-ad68-407069d14739	authenticated	authenticated	nguyennguyenvanhieu1omd7@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Văn Hiếu", "username": "nguyennguyenvanhieu1omd7", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "448b9293-3aaf-407b-84c6-19248be921dc"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	638974a3-c540-40d1-ad2d-98bfc0f01575	authenticated	authenticated	nguyenlethithuyhoaiq61b0@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Thúy Hoài", "username": "nguyenlethithuyhoaiq61b0", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "7ec83d50-e289-45d9-93b6-ea63f452bc10"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f08bf144-b2b4-475a-935e-c8e6e0bf25b7	authenticated	authenticated	nguyendaovietkhanh0r6xr@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đào Viết Khánh", "username": "nguyendaovietkhanh0r6xr", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "971d34f8-5d88-4cc3-829a-3f0e3a8e12d2"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7b3125f0-7239-490b-9d70-4714cb1dc80b	authenticated	authenticated	nguyendinhngockhanhhuyen0i1sz@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đinh Ngọc Khánh Huyền", "username": "nguyendinhngockhanhhuyen0i1sz", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "09931a14-bced-4a57-9101-95dd77dc8153"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6a5dc59d-90fa-4834-9a66-d67769cd06fa	authenticated	authenticated	nguyenphamquochungdrd4f@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Quốc Hưng", "username": "nguyenphamquochungdrd4f", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "e00b2c49-14af-4a75-91a9-23adf778485c"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	40b0d73e-f312-432b-b60e-933a22431a45	authenticated	authenticated	nguyennguyenquangkien58zgp@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Quang Kiên", "username": "nguyennguyenquangkien58zgp", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "041432f6-cf79-4198-aa5b-b49454033b6d"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	26298684-b502-4295-a6dd-143f17dfc6cd	authenticated	authenticated	nguyennguyenkhanhlinh2iody@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Khánh Linh", "username": "nguyennguyenkhanhlinh2iody", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "ac788eb5-a8ae-4a13-861b-a81f9c6a5bb3"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	616b1e84-bcb2-4660-8792-7c8417cb1289	authenticated	authenticated	nguyennguyenphilongaelrk@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Phi Long", "username": "nguyennguyenphilongaelrk", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "d0aa648a-489f-4098-b6ec-e6c3a7a2acc5"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e3c565ea-3424-4776-9a09-ff09eb86b3fe	authenticated	authenticated	nguyentranducluong7t2g2@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trần Đức Lương", "username": "nguyentranducluong7t2g2", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "d0222c30-f003-4f6c-bf98-6825b60d003d"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	8c7126f6-f652-4a67-ba6f-7014cc5b5b0c	authenticated	authenticated	nguyenhothikhanhlyyd973@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thị Khánh Ly", "username": "nguyenhothikhanhlyyd973", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "82ffd4dc-2ea9-47c5-8530-1bcbebfe7a18"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cf065d52-ad66-4b78-b363-ba172b3df233	authenticated	authenticated	nguyennguyenhoangbaominh4lzjo@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Hoàng Bảo Minh", "username": "nguyennguyenhoangbaominh4lzjo", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "b62028d5-9b47-4476-8fba-d4bfc62a9dd5"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	8c5cb5ba-1b8c-46e6-a824-b754432c83b2	authenticated	authenticated	nguyenhothungajwt62@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thu Nga", "username": "nguyenhothungajwt62", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "62ad74b4-19b8-44ed-a72f-cffa3ec88d90"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	01447e69-9492-4f95-a121-bc2fe91d597d	authenticated	authenticated	nguyentrinhthihangnga4i5k1@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trịnh Thị Hằng Nga", "username": "nguyentrinhthihangnga4i5k1", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "abe14198-7285-4639-9a5a-dccebb61a5eb"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:22:40.425401+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2439ebcf-6ec0-474f-bba5-7c78987fb566	authenticated	authenticated	nguyennguyenlucngansyisy@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Lục Ngạn", "username": "nguyennguyenlucngansyisy", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "15545814-0567-4824-8255-6f4da1cd63d6"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a50e50d7-de39-468c-b113-3eeea052e820	authenticated	authenticated	nguyenlehoangmyngoc13n5i@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Hoàng Mỹ Ngọc", "username": "nguyenlehoangmyngoc13n5i", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "9c90c250-09fa-4f99-a1c3-502c943945ce"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	13983a4f-94ca-439b-981b-8267c2191463	authenticated	authenticated	nguyenlethibaongoczoq5v@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Bảo Ngọc", "username": "nguyenlethibaongoczoq5v", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "8a1a9971-689e-425b-8958-fb342684020c"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3776c32b-bc8f-444e-9ebe-5d33c7ef2736	authenticated	authenticated	nguyencaoanhnhani1xgm@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Cao Anh Nhân", "username": "nguyencaoanhnhani1xgm", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "132de78f-f29a-4b68-9726-a98367425ab1"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3cc19ce0-0eb4-4776-9928-1e966e86f22e	authenticated	authenticated	nguyenlevothanhnhat3wbwa@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Võ Thanh Nhật", "username": "nguyenlevothanhnhat3wbwa", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "cd628b22-7416-4888-8ae5-c97bfc46280a"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ffdc88e2-81fc-4e94-adbc-80ad77f036e8	authenticated	authenticated	nguyendangthithuphuonglngtm@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đặng Thị Thu Phương", "username": "nguyendangthithuphuonglngtm", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "fcb9faa7-0d0c-4eed-b84f-5c11152ad276"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5e1d165d-8f0d-48b3-a9cd-b9c945fc2f45	authenticated	authenticated	nguyendobaoquangrpiwm@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đỗ Bảo Quang", "username": "nguyendobaoquangrpiwm", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "64fae51a-8d7e-46a2-bdf9-41e678edadbc"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	0e32a947-ec26-453e-848a-e40d04facfc9	authenticated	authenticated	nguyenhohuuquangjtpr4@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Hữu Quang", "username": "nguyenhohuuquangjtpr4", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "a19587b9-8204-418c-b092-4371c40d2b6e"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	77cccf47-6e09-46f6-a502-ca0575c000eb	authenticated	authenticated	nguyenhokhacanhquan9hd6e@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hô Khắc Anh Quân", "username": "nguyenhokhacanhquan9hd6e", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "1db5e7ce-937b-420a-b057-33d9736f57c4"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7528d14f-0ff3-49ac-81d5-82a783bc0544	authenticated	authenticated	nguyenhosyquan0k4q7@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Sỹ Quân", "username": "nguyenhosyquan0k4q7", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "60302e80-0f5a-4ab5-85ec-a932aaa1b608"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	500e4700-32c3-49cf-b5a2-0055e972364c	authenticated	authenticated	nguyenphamvunhuquynhdzqyu@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phạm Vũ Như Quỳnh", "username": "nguyenphamvunhuquynhdzqyu", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "0d52f50b-a046-4147-b37e-cb0ed55d536f"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a34e769d-9d6d-4803-8503-c0de637b7156	authenticated	authenticated	nguyennguyenngoclanthanh9xru8@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Ngọc Lan Thanh", "username": "nguyennguyenngoclanthanh9xru8", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "2b3f9240-abdf-4f5f-9c5a-3b9a7bc6faad"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	eade77e9-c327-4c3e-8bc7-65a11764ddc1	authenticated	authenticated	nguyenvohanhthaoktlgj@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Võ Hạnh Thảo", "username": "nguyenvohanhthaoktlgj", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "756c505d-8d9a-4334-97a9-c4badc77a6d5"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	6de7616a-b41c-4bb6-afe4-851003c0c5cf	authenticated	authenticated	nguyentranhongthek5lwg@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Trần Hồng Thế", "username": "nguyentranhongthek5lwg", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "996643f5-ca6d-4636-a6e4-24b619b18d50"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9cbf8c98-e87e-4f8d-b241-02212258489d	authenticated	authenticated	nguyenduongducthinh9opxt@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Dương Đức Thịnh", "username": "nguyenduongducthinh9opxt", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "aa20250d-03d5-4a33-b996-dbcb56f21d50"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	80dc6510-2738-4d46-9661-0ca816597447	authenticated	authenticated	nguyenphanngocthinhdrt1t@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Phan Ngọc Thịnh", "username": "nguyenphanngocthinhdrt1t", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "e58f30ba-2bcb-4cb7-86ba-92958e6b98b5"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5381ca73-3cbb-42ee-8a81-ce3ae54a6613	authenticated	authenticated	nguyenbuithilythu3b55a@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Bùi Thị Lý Thu", "username": "nguyenbuithilythu3b55a", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "ea0169ae-885f-4c70-b3b8-d2043dce9bc0"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	aeb05f8c-b912-45f9-95ea-5495b3c07358	authenticated	authenticated	nguyenhonguyenkhanhtrangej87c@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Nguyễn Khánh Trang", "username": "nguyenhonguyenkhanhtrangej87c", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "7bddb6b5-c31b-4294-b3d7-7c43c9499f9e"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	cd675169-a109-4487-aaf8-79666943be90	authenticated	authenticated	nguyenhothithuytrang98oit@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Hồ Thị Thùy Trang", "username": "nguyenhothithuytrang98oit", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "47469c02-bf2a-4a7e-a9c2-7bc1f65a678f"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	8d86cb6b-26d7-478b-bc86-58e094ee337a	authenticated	authenticated	nguyenlethithuytrang3r372@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.679133+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Lê Thị Thùy Trang", "username": "nguyenlethithuytrang3r372", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "81d9ce82-6ea1-4fcd-8355-4d6f2005fd0a"}	\N	2026-08-19 14:22:40.679133+00	2026-08-19 14:22:40.679133+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b196b679-ab45-4697-a4a5-0691766533a7	authenticated	authenticated	nguyennguyenthihuyentranghicmt@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.850163+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Thị Huyền Trang", "username": "nguyennguyenthihuyentranghicmt", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "1a9ffd96-d050-4717-9c76-32711f665dfd"}	\N	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a165eef6-ca63-4790-b35b-95866479b25d	authenticated	authenticated	nguyennguyentranhuyentrangn7xzz@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.850163+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Trần Huyền Trang", "username": "nguyennguyentranhuyentrangn7xzz", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "9bb5aac9-ca5d-4821-95f3-e5809a20b292"}	\N	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	47cd6b7e-748d-4628-9a00-4a27b5d4bf73	authenticated	authenticated	nguyennguyenquoctrong25sy2@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.850163+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Nguyễn Quốc Trọng", "username": "nguyennguyenquoctrong25sy2", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "2dd1edeb-ba60-422c-af39-51ec2572fc69"}	\N	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d67484f1-c987-43d1-b0c5-0966b669ec64	authenticated	authenticated	nguyendoantuongvyyljwv@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.850163+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Đoàn Tường Vy", "username": "nguyendoantuongvyyljwv", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "437551b2-5236-46f0-a1e0-6aee292625c3"}	\N	2026-08-19 14:22:40.850163+00	2026-08-19 14:22:40.850163+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	100f0e53-4030-4fab-8a20-d0e0577cd36f	authenticated	authenticated	nguyenbuingocdatdjtgr@htqltd.vn	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	2026-08-19 14:22:40.425401+00	\N		\N		\N			\N	2026-08-19 14:23:00.860502+00	{"provider": "email", "providers": ["email"]}	{"role": "DV", "fullname": "Nguyễn Bùi Ngọc Đạt", "username": "nguyenbuingocdatdjtgr", "chidoan_id": "1aa48c10-6d5d-4c33-93aa-7edf3f7f7122", "doanvien_id": "5b408617-e97c-48f1-80ba-8b3f9331405b"}	\N	2026-08-19 14:22:40.425401+00	2026-08-19 14:23:00.954146+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: cauhinh_tieuchi_xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cauhinh_tieuchi_xet_thidua" ("id", "namhoc_id", "hoc_ky", "ten_tieuchi_1", "sudung_1", "kieudulieu_1", "ten_tieuchi_2", "sudung_2", "kieudulieu_2", "ten_tieuchi_3", "sudung_3", "kieudulieu_3", "ten_tieuchi_4", "sudung_4", "kieudulieu_4", "ten_tieuchi_5", "sudung_5", "kieudulieu_5", "ten_tieuchi_6", "sudung_6", "kieudulieu_6", "ten_tieuchi_7", "sudung_7", "kieudulieu_7", "ten_tieuchi_8", "sudung_8", "kieudulieu_8", "ten_tieuchi_9", "sudung_9", "kieudulieu_9", "ten_tieuchi_10", "sudung_10", "kieudulieu_10", "created_at", "updated_at", "ghi_chu", "giai_thich", "trang_thai") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
f541f4d8-5963-4691-b576-caa19be40ccf	ad40294c-5077-4af0-a9f1-421e5ffe1c38	HK1	1	Thứ 5	2026-08-06	ba017e7f-ae9e-42b6-8727-850952ec09d6	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	21735797-3a80-4b5c-b8af-f30fe139af5d	Nguyễn Phạm Dương Anh	TC02	Cúp tiết	Vi phạm	5	0		Quản trị	2026-08-06 00:21:01.220089+00	\N	2026-08-06 00:21:01.220089+00
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat", "sothedoan", "phuongtien", "thongtinphuongtien") FROM stdin;
21735797-3a80-4b5c-b8af-f30fe139af5d	Nguyễn Phạm Dương Anh	20/10/2026	Nam	Kinh	\N	t	\N	17/01/2026	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
c11d1f63-4b71-4a31-ba4c-892cf5880657	Nguyễn Phạm Văn Bé	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
55a34912-a53c-49a0-a145-2e93fcf4125e	Nguyễn Lương Thanh Bình	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
5b408617-e97c-48f1-80ba-8b3f9331405b	Nguyễn Bùi Ngọc Đạt	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
8f2d6bd4-7367-4eeb-9f52-9e243e522472	Nguyễn TRẦN KHÁNH HÀ	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
fe4ff85d-5eb8-4a3e-902c-4a6a6fecab20	Nguyễn Nguyễn Công Hậu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
a7fe6c1e-2e91-4594-9b77-fa74e64e58cc	Nguyễn Nguyễn Đức Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
448b9293-3aaf-407b-84c6-19248be921dc	Nguyễn Nguyễn Văn Hiếu	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
7ec83d50-e289-45d9-93b6-ea63f452bc10	Nguyễn Lê Thị Thúy Hoài	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
09931a14-bced-4a57-9101-95dd77dc8153	Nguyễn Đinh Ngọc Khánh Huyền	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
e00b2c49-14af-4a75-91a9-23adf778485c	Nguyễn Phạm Quốc Hưng	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
971d34f8-5d88-4cc3-829a-3f0e3a8e12d2	Nguyễn Đào Viết Khánh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
041432f6-cf79-4198-aa5b-b49454033b6d	Nguyễn Nguyễn Quang Kiên	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
ac788eb5-a8ae-4a13-861b-a81f9c6a5bb3	Nguyễn Nguyễn Khánh Linh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
d0aa648a-489f-4098-b6ec-e6c3a7a2acc5	Nguyễn Nguyễn Phi Long	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
d0222c30-f003-4f6c-bf98-6825b60d003d	Nguyễn Trần Đức Lương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
82ffd4dc-2ea9-47c5-8530-1bcbebfe7a18	Nguyễn Hồ Thị Khánh Ly	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
b62028d5-9b47-4476-8fba-d4bfc62a9dd5	Nguyễn Nguyễn Hoàng Bảo Minh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
62ad74b4-19b8-44ed-a72f-cffa3ec88d90	Nguyễn Hồ Thu Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
abe14198-7285-4639-9a5a-dccebb61a5eb	Nguyễn Trịnh Thị Hằng Nga	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
15545814-0567-4824-8255-6f4da1cd63d6	Nguyễn Nguyễn Lục Ngạn	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
9c90c250-09fa-4f99-a1c3-502c943945ce	Nguyễn Lê Hoàng Mỹ Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
8a1a9971-689e-425b-8958-fb342684020c	Nguyễn Lê Thị Bảo Ngọc	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
132de78f-f29a-4b68-9726-a98367425ab1	Nguyễn Cao Anh Nhân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
cd628b22-7416-4888-8ae5-c97bfc46280a	Nguyễn Lê Võ Thanh Nhật	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
fcb9faa7-0d0c-4eed-b84f-5c11152ad276	Nguyễn Đặng Thị Thu Phương	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
64fae51a-8d7e-46a2-bdf9-41e678edadbc	Nguyễn Đỗ Bảo Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
a19587b9-8204-418c-b092-4371c40d2b6e	Nguyễn Hồ Hữu Quang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
1db5e7ce-937b-420a-b057-33d9736f57c4	Nguyễn Hô Khắc Anh Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
60302e80-0f5a-4ab5-85ec-a932aaa1b608	Nguyễn Hồ Sỹ Quân	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
0d52f50b-a046-4147-b37e-cb0ed55d536f	Nguyễn Phạm Vũ Như Quỳnh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
2b3f9240-abdf-4f5f-9c5a-3b9a7bc6faad	Nguyễn Nguyễn Ngọc Lan Thanh	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
756c505d-8d9a-4334-97a9-c4badc77a6d5	Nguyễn Võ Hạnh Thảo	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
996643f5-ca6d-4636-a6e4-24b619b18d50	Nguyễn Trần Hồng Thế	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
aa20250d-03d5-4a33-b996-dbcb56f21d50	Nguyễn Dương Đức Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
e58f30ba-2bcb-4cb7-86ba-92958e6b98b5	Nguyễn Phan Ngọc Thịnh	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
ea0169ae-885f-4c70-b3b8-d2043dce9bc0	Nguyễn Bùi Thị Lý Thu	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
7bddb6b5-c31b-4294-b3d7-7c43c9499f9e	Nguyễn Hồ Nguyễn Khánh Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
47469c02-bf2a-4a7e-a9c2-7bc1f65a678f	Nguyễn Hồ Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
81d9ce82-6ea1-4fcd-8355-4d6f2005fd0a	Nguyễn Lê Thị Thùy Trang	20/10/2026	Nam	Kinh	\N	f	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
1a9ffd96-d050-4717-9c76-32711f665dfd	Nguyễn Nguyễn Thị Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
9bb5aac9-ca5d-4821-95f3-e5809a20b292	Nguyễn Nguyễn Trần Huyền Trang	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
2dd1edeb-ba60-422c-af39-51ec2572fc69	Nguyễn Nguyễn Quốc Trọng	20/10/2026	Nam	Kinh	\N	t	\N	-	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
437551b2-5236-46f0-a1e0-6aee292625c3	Nguyễn Đoàn Tường Vy	20/10/2026	Nam	Kinh	\N	t	\N	24/03/2025	\N	\N	2026-08-06 00:20:12.994941+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	Xã ABC - tỉnh ABC - Việt Nam	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:12.994941+00	\N	\N	\N
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
3c2fc68f-284f-46a8-b304-eb6f007c896d	362	2026-08-05 15:08:32.614123+00	2026-08-05 15:08:32.614123+00	2026-08-21 11:58:03.612241+00
\.


--
-- Data for Name: gio_hoc_tap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."gio_hoc_tap" ("id", "namhoc_id", "chidoan_id", "tuan_id", "so_tot", "so_kha", "so_tb", "so_yeu", "diem_tot_cauhinh", "diem_kha_cauhinh", "diem_tb_cauhinh", "diem_yeu_cauhinh", "diem_tb_hoc_tap", "updated_at", "hocky") FROM stdin;
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
project_02	congty/du_an_backend	main	supabase-backup.yml	supabase-restore.yml	ghp_abc123...	2026-08-05 15:08:32.614123+00	\N	2026-08-05 15:08:32.614123+00	2026-08-05 15:08:32.614123+00
default	hohuuthe/gialaithptso2nguyentruongto	main	supabase-backup.yml	supabase-restore.yml	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	2026-08-06 00:25:29.855+00	Admin	2026-08-06 00:25:29.575219+00	2026-08-06 00:25:29.575219+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-2027	f	2026-08-05 15:18:00.990185+00	2026-08-05 15:18:00.990185+00	f
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
5b160199-0955-48d8-a4a5-cfe66e81c9bf	HK1	1	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	aaddd1ce-4c32-411c-af4a-cf1cc96ddf81	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
d154ed21-a006-4391-be6f-7b828631e674	HK1	1	aaddd1ce-4c32-411c-af4a-cf1cc96ddf81	086f70a7-25da-4ef9-8815-6a240042894c	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
30c93a17-3ee8-4694-9b8e-d8dfd978a7ea	HK1	1	086f70a7-25da-4ef9-8815-6a240042894c	aa92a0a4-13db-4918-90a2-086e8b7ed995	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
5aa3c11c-6bb9-4437-b4d2-c48dbe5a7d3a	HK1	1	aa92a0a4-13db-4918-90a2-086e8b7ed995	e62b89f4-f3ed-487d-9ca8-8dc6cd1a140e	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
324166e5-c95f-4ddf-987b-0fc2ff156901	HK1	1	e62b89f4-f3ed-487d-9ca8-8dc6cd1a140e	1220e9df-ba9e-4e69-b867-6916a888f90e	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
c63d81e6-aece-4c4d-bf69-d3786be32452	HK1	1	1220e9df-ba9e-4e69-b867-6916a888f90e	e72e7a23-b99c-4294-9e4c-82141dcaebb7	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
de0e2d0e-c224-49e5-80f8-8c618b0d9237	HK1	1	e72e7a23-b99c-4294-9e4c-82141dcaebb7	dbc0d7f4-4005-4167-9c92-5e2f18a77358	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
73fad938-aecb-40f2-b631-653ff10412d5	HK1	1	dbc0d7f4-4005-4167-9c92-5e2f18a77358	f02e35d4-b01b-4ea5-9ace-ddbb328c346c	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
7882e979-b633-4aea-8d5f-0d8e75f6eb88	HK1	1	f02e35d4-b01b-4ea5-9ace-ddbb328c346c	e1c623c9-7f7e-40e8-a6a7-5ca4b735d4f3	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
69d39241-ee9d-45cf-b992-6c805aa58680	HK1	1	e1c623c9-7f7e-40e8-a6a7-5ca4b735d4f3	9408607d-a882-4155-b6e9-ba8157fb3013	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
a5af826b-ab9f-4bb5-b38a-a38b19cfc5f6	HK1	1	9408607d-a882-4155-b6e9-ba8157fb3013	4d13785b-af69-465b-8cb4-e7ec1edc25e9	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
ee72672a-370e-4fe3-bbc6-753abca8ab44	HK1	1	4d13785b-af69-465b-8cb4-e7ec1edc25e9	dc0e04b2-f7ce-47c8-9bd8-82f5e052c1a1	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
71f2cfcc-7102-4be3-b01b-64c528050d0a	HK1	1	dc0e04b2-f7ce-47c8-9bd8-82f5e052c1a1	195fcbb9-f711-4b24-b4e5-7a8eca2d9b39	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
25703387-3e6e-482d-b653-8405f5df466e	HK1	1	195fcbb9-f711-4b24-b4e5-7a8eca2d9b39	52146929-7c55-4076-b523-92595db0f4fe	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
0c435205-af04-4c9f-a9c8-7ecc4690d4f9	HK1	1	52146929-7c55-4076-b523-92595db0f4fe	b450069a-7307-47ba-b454-3f316f097989	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
4cc948e4-6a04-4cc9-b0b5-ae3fb757de6d	HK1	1	b450069a-7307-47ba-b454-3f316f097989	36c1bb17-81fa-463d-9c8e-c32c75ddfa5b	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
8e5b01e2-114b-4b0f-a695-e6db8d4ce838	HK1	1	36c1bb17-81fa-463d-9c8e-c32c75ddfa5b	7388f282-054d-4918-b8d5-669f347a611e	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
1d9acf37-8bc1-4e47-b606-eff7a8a9b23d	HK1	1	7388f282-054d-4918-b8d5-669f347a611e	78ab8893-d21e-4b32-8f71-76cc3bf26219	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
ef999daf-7272-4330-98cb-bdbb3356ec6d	HK1	1	78ab8893-d21e-4b32-8f71-76cc3bf26219	8534750d-d62b-44ee-a2a2-26a1cb1f61c3	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
6570e212-3ac4-4ac7-a3e3-0aa7ebc1777b	HK1	1	8534750d-d62b-44ee-a2a2-26a1cb1f61c3	15dfd29c-8886-4ec8-a877-aadf57873437	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
d0024efe-fa77-4552-a9d7-5e5cbcf38849	HK1	1	15dfd29c-8886-4ec8-a877-aadf57873437	da2d3090-d9c2-478e-adb5-d2c086d6c086	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
4317d2c1-af8f-44b8-a716-c281f0e96ba3	HK1	1	da2d3090-d9c2-478e-adb5-d2c086d6c086	72cdbece-bbbd-4333-9673-c93165c1c580	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
222e713c-c122-46ce-9de0-1d1f63b16b79	HK1	1	72cdbece-bbbd-4333-9673-c93165c1c580	c78c78b9-fea0-4656-88cc-d45cb46a0052	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
86a5de42-a777-4608-a33c-79c97c4ba675	HK1	1	c78c78b9-fea0-4656-88cc-d45cb46a0052	950a9ff0-24b8-4fef-88da-33d4eed99a36	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
94412089-62d5-43c8-ad3b-e043d138c020	HK1	1	950a9ff0-24b8-4fef-88da-33d4eed99a36	7b911d84-34bc-4885-8d0a-645afbcfc529	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
4133d591-f713-44d8-a49d-72356310f6f7	HK1	1	7b911d84-34bc-4885-8d0a-645afbcfc529	2767e7d6-d17b-4490-888c-d86afbdaf667	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
1eab4747-94a8-458b-98ef-ed0e5750b3dc	HK1	1	2767e7d6-d17b-4490-888c-d86afbdaf667	ee190e57-4414-4705-bb26-ca4c50c00fa5	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
78c15b1f-fbfe-452b-b2fe-64ec7b96c6b4	HK1	1	ee190e57-4414-4705-bb26-ca4c50c00fa5	26d58252-f561-412f-a359-1d4b28619713	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
eb2890ca-d396-4df8-9a19-115aa66761f3	HK1	1	26d58252-f561-412f-a359-1d4b28619713	00508630-a0c3-4275-b638-d01d487b235d	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
e7ff20a4-6c82-4d4e-bb90-25462eadc5d4	HK1	1	00508630-a0c3-4275-b638-d01d487b235d	1ba15fc4-31da-402a-830c-69e03bef2bfb	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
dad526b4-54b8-4271-bc21-4220e6b6e5bd	HK1	1	1ba15fc4-31da-402a-830c-69e03bef2bfb	8102c088-3ddb-41ee-9cb9-41b12a9a6ca7	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
e3f4849e-c0e7-41c0-b3d5-e659414933e0	HK1	1	8102c088-3ddb-41ee-9cb9-41b12a9a6ca7	ba017e7f-ae9e-42b6-8727-850952ec09d6	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
f942d278-b6b8-49b4-8e6d-f61290d4467b	HK1	1	ba017e7f-ae9e-42b6-8727-850952ec09d6	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-06 00:20:43.658948+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:43.658948+00
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "ngay_cap_nhat", "nam_hoc", "createdat", "updatedat", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "giai_thich") FROM stdin;
1	BGH	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
2	BGH	qlchidoan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
3	BGH	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
4	BGH	ptdoanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
5	BGH	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
6	BGH	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
7	BGH	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
8	BGH	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
9	BGH	baocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
10	BGH	tonghopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
11	BGH	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
12	BGH	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
13	BGH	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
14	BTV	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
15	BTV	qlchidoan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
17	BTV	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
18	BTV	ptdoanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
19	BTV	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
20	BTV	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
21	BTV	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
22	BTV	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
23	BTV	baocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
24	BTV	tonghopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
25	BTV	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
26	BTV	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	t	t	t	
27	BTV	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
29	BTV	phanquyen	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
30	BTV	saoluu	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:20:10.806378+00	2026-08-05 21:58:01.656119+00	t	f	f	f	
61	BCH	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
62	BCH	qlchidoan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	t	f	\N
64	BCH	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	t	f	\N
65	BCH	ptdoanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
66	BCH	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
67	BCH	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
69	BCH	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
70	BCH	baocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
71	BCH	tonghopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
72	BCH	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
73	BCH	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
74	BCH	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	t	f	\N
75	GVCN	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
76	GVCN	qlchidoan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
79	GVCN	ptdoanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
80	GVCN	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
81	GVCN	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
82	GVCN	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
83	GVCN	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
78	GVCN	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	2026-08-14 15:02:43.94063+00	t	f	f	f	\N
68	BCH	chamdiem	2026-08-14 18:31:14.605843+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	2026-08-14 18:31:14.605843+00	t	f	f	f	\N
84	GVCN	baocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
85	GVCN	tonghopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
86	GVCN	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
87	GVCN	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
88	GVCN	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
89	NC	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
90	NC	qlchidoan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
91	NC	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
92	NC	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
93	NC	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
94	NC	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
95	NC	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
96	NC	baocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
97	NC	tonghopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
98	NC	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
99	NC	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
100	NC	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
101	DV	tongquan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
103	DV	ptdoanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
104	DV	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
105	DV	phancong	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
106	DV	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
107	DV	namtuan	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
108	DV	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
109	DV	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
110	DV	theodoi360	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	t	t	t	\N
111	PH	tieuchitd	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
112	PH	chamdiem	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
113	PH	qlbaocao	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
114	PH	qlnopbc	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	\N	t	f	f	f	\N
102	DV	doanvien	2026-08-05 21:58:01.748+00	ad40294c-5077-4af0-a9f1-421e5ffe1c38	\N	2026-08-14 15:02:43.94063+00	t	f	f	f	\N
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."push_subscriptions" ("id", "user_id", "role", "chidoan_id", "subscription", "endpoint", "created_at") FROM stdin;
\.


--
-- Data for Name: ql_baocao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_baocao" ("id", "chu_de", "chu_de_phu", "tu_ngay", "den_ngay", "cho_phep_minh_chung", "doi_tuong_nop", "huong_dan", "ngay_tao", "nam_hoc_id", "hoc_ky", "config_noi_dung1", "config_noi_dung2", "config_noi_dung3", "config_noi_dung4", "config_noi_dung5", "config_noi_dung6", "config_noi_dung7", "config_noi_dung8", "config_noi_dung9", "config_noi_dung10", "allowed_file_types", "max_file_size") FROM stdin;
\.


--
-- Data for Name: ql_nop_bc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ql_nop_bc" ("id", "ql_bao_cao_id", "doanvien_id", "noi_dung1", "noi_dung2", "noi_dung3", "noi_dung4", "noi_dung5", "noi_dung6", "noi_dung7", "noi_dung8", "noi_dung9", "noi_dung10", "duong_dan_minh_chung", "ghi_chu", "trang_thai", "ngay_capnhat", "chi_doan_id", "danh_sach_anh", "vaitro_nop", "doituong_nop", "nguoi_tao_id") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat", "he_so_tru", "he_so_cong") FROM stdin;
1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	10A1	Chiều	TN	11	Nguyễn Khánh Linh	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
aaddd1ce-4c32-411c-af4a-cf1cc96ddf81	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
086f70a7-25da-4ef9-8815-6a240042894c	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
aa92a0a4-13db-4918-90a2-086e8b7ed995	10A4	Chiều	TN	8	Phạm Hà Anh	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
e62b89f4-f3ed-487d-9ca8-8dc6cd1a140e	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
1220e9df-ba9e-4e69-b867-6916a888f90e	10A6	Chiều	XH	1	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
e72e7a23-b99c-4294-9e4c-82141dcaebb7	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
dbc0d7f4-4005-4167-9c92-5e2f18a77358	10A8	Chiều	XH	3	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
f02e35d4-b01b-4ea5-9ace-ddbb328c346c	10A9	Chiều	XH	4	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
e1c623c9-7f7e-40e8-a6a7-5ca4b735d4f3	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
9408607d-a882-4155-b6e9-ba8157fb3013	10A11	Chiều	XH	6	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
4d13785b-af69-465b-8cb4-e7ec1edc25e9	11C1	Chiều	TN	12	Lê Minh Phương	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
dc0e04b2-f7ce-47c8-9bd8-82f5e052c1a1	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
195fcbb9-f711-4b24-b4e5-7a8eca2d9b39	11C3	Chiều	TN	14	Phạm Minh Anh	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
52146929-7c55-4076-b523-92595db0f4fe	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
b450069a-7307-47ba-b454-3f316f097989	11C5	Chiều	TN	16	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
36c1bb17-81fa-463d-9c8e-c32c75ddfa5b	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
7388f282-054d-4918-b8d5-669f347a611e	11C7	Sáng	XH	2	nguyễn hồng lai	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
78ab8893-d21e-4b32-8f71-76cc3bf26219	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
8534750d-d62b-44ee-a2a2-26a1cb1f61c3	11C9	Sáng	XH	4	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
15dfd29c-8886-4ec8-a877-aadf57873437	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
da2d3090-d9c2-478e-adb5-d2c086d6c086	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
72cdbece-bbbd-4333-9673-c93165c1c580	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
c78c78b9-fea0-4656-88cc-d45cb46a0052	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
950a9ff0-24b8-4fef-88da-33d4eed99a36	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
7b911d84-34bc-4885-8d0a-645afbcfc529	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
2767e7d6-d17b-4490-888c-d86afbdaf667	12B4	Sáng	TN	11	\N	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
ee190e57-4414-4705-bb26-ca4c50c00fa5	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
26d58252-f561-412f-a359-1d4b28619713	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
00508630-a0c3-4275-b638-d01d487b235d	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
1ba15fc4-31da-402a-830c-69e03bef2bfb	12B8	Sáng	XH	15	Quế Trân	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
8102c088-3ddb-41ee-9cb9-41b12a9a6ca7	12B9	Sáng	XH	16	Thành Tín	\N	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
ba017e7f-ae9e-42b6-8727-850952ec09d6	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:19:58.447933+00	2026-08-06 00:19:58.447933+00	1	1
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat", "cloudinary_cloud_name", "cloudinary_upload_preset", "cloudinary_api_key", "cloudinary_api_secret", "r2_account_id", "r2_access_key_id", "r2_secret_access_key", "r2_bucket_name", "r2_custom_domain", "show_class_select_gvcn", "diem_tot", "diem_kha", "diem_tb", "diem_yeu", "ti_trong_diem_tuan", "ti_trong_diem_hoc_tap") FROM stdin;
a97fe935-8619-47cd-86ea-017b0f466b38	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT số 2 Nguyễn Trường Tộ	0		AQ.Ab8RN6KwmnG0mbqBTwrCVzHZ6CFCTswsLoAcQN2TzxH4u_mW6g	0		\N	\N	\N	\N	23:55	30	Lỗi không báo cáo điểm tuần	f	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[U][C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-05 15:19:15.961717+00	2026-08-06 02:59:32.784497+00					3b892f62e27043f7355c59b3a050f588	af047231384801a21c68ecaac116c437	164e15d8d68a97a145b9238ff02e7cc317f0ad851b4cf1bfbb45649b458dcf4d	gialaithptso2nguyentruongto	https://pub-cfc46e010f594a758fd2d73f3c153f0a.r2.dev	Không hiển thị	10	7	4	1	50	50
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat", "doanvien_id", "sl_dangnhap", "tg_truycap", "chidoan1111") FROM stdin;
3b11a5b8-b917-4333-9eb8-2af82b14878e	nguyenhohuuquangjtpr4	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Hữu Quang	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	a19587b9-8204-418c-b092-4371c40d2b6e	0	\N	\N
9f02099d-4506-4817-ae1a-3b24b53723a5	nguyenhokhacanhquan9hd6e	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hô Khắc Anh Quân	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	1db5e7ce-937b-420a-b057-33d9736f57c4	0	\N	\N
3f1d18ce-fded-435a-8078-dccaeb21549f	nguyenhosyquan0k4q7	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Sỹ Quân	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	60302e80-0f5a-4ab5-85ec-a932aaa1b608	0	\N	\N
9b86adcb-1938-494f-a83d-d888835d7c92	nguyenphamvunhuquynhdzqyu	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Phạm Vũ Như Quỳnh	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	0d52f50b-a046-4147-b37e-cb0ed55d536f	0	\N	\N
f77869a8-12ca-4445-8ec1-b46b89fc97e4	nguyennguyenngoclanthanh9xru8	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Ngọc Lan Thanh	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	2b3f9240-abdf-4f5f-9c5a-3b9a7bc6faad	0	\N	\N
23765e68-8621-4401-b30f-d16567ba08fd	Admin	$2a$10$3vMdAtZIpRCGbbJeYBuh8uf5ShESvTov0guPgg6P5DCx0W8UTEbI2	Quản trị	Admin	2026-08-19 14:22:26.710605+00	\N	2026-08-05 15:08:32.614123+00	\N	4	2026-08-19 21:22:26+00	\N
608a8629-3a4e-4195-b317-fb072494eb75	nguyenphamduonganhcoygr	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Phạm Dương Anh	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	21735797-3a80-4b5c-b8af-f30fe139af5d	0	\N	\N
da65565f-6a44-4d0a-86d1-73c5ad6fea1f	nguyenphamvanbebtn96	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Phạm Văn Bé	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	c11d1f63-4b71-4a31-ba4c-892cf5880657	0	\N	\N
e6d39550-d242-4971-a3fc-2f77c31314ca	nguyenluongthanhbinhyntsj	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lương Thanh Bình	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	55a34912-a53c-49a0-a145-2e93fcf4125e	0	\N	\N
86b0d3e1-9199-4d68-8b8b-6115aa217a9d	nguyenbuingocdatdjtgr	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Bùi Ngọc Đạt	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	5b408617-e97c-48f1-80ba-8b3f9331405b	0	\N	\N
a58ac32b-d9b0-4cdf-b225-30d4e7e3e6b6	nguyentrankhanhha2ny54	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn TRẦN KHÁNH HÀ	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	8f2d6bd4-7367-4eeb-9f52-9e243e522472	0	\N	\N
bb9696a5-b819-4dc7-8a49-13ac6ea300e2	nguyennguyenconghauxs99l	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Công Hậu	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	fe4ff85d-5eb8-4a3e-902c-4a6a6fecab20	0	\N	\N
8654d1bb-f46e-4ad7-8464-1c9c99cf2d5e	nguyennguyenduchieuyhlmk	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Đức Hiếu	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	a7fe6c1e-2e91-4594-9b77-fa74e64e58cc	0	\N	\N
ec011e57-20a6-4f9c-a12b-2c93b1fd0e3b	nguyennguyenvanhieu1omd7	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Văn Hiếu	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	448b9293-3aaf-407b-84c6-19248be921dc	0	\N	\N
6257d5b7-7b37-43cb-9cad-de4ad31f2d99	nguyenlethithuyhoaiq61b0	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lê Thị Thúy Hoài	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	7ec83d50-e289-45d9-93b6-ea63f452bc10	0	\N	\N
47c6f9d4-056d-4808-8af7-32ab6572533f	nguyendinhngockhanhhuyen0i1sz	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Đinh Ngọc Khánh Huyền	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	09931a14-bced-4a57-9101-95dd77dc8153	0	\N	\N
dadde049-2bf9-49e1-9092-1b13fd6db9a2	nguyenphamquochungdrd4f	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Phạm Quốc Hưng	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	e00b2c49-14af-4a75-91a9-23adf778485c	0	\N	\N
e57745eb-e959-45c2-8e8b-1ea2c71028ca	nguyendaovietkhanh0r6xr	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Đào Viết Khánh	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	971d34f8-5d88-4cc3-829a-3f0e3a8e12d2	0	\N	\N
a9654a2c-f307-4b97-b3ee-a22776b8f82f	nguyennguyenquangkien58zgp	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Quang Kiên	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	041432f6-cf79-4198-aa5b-b49454033b6d	0	\N	\N
bed8146e-0962-43d6-a034-321ffecd4857	nguyennguyenkhanhlinh2iody	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Khánh Linh	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	ac788eb5-a8ae-4a13-861b-a81f9c6a5bb3	0	\N	\N
f7f079b6-b8fb-49e0-8bc4-24a06fdfa408	nguyennguyenphilongaelrk	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Phi Long	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	d0aa648a-489f-4098-b6ec-e6c3a7a2acc5	0	\N	\N
c63acc04-238f-43ff-ab93-994f4cd83f85	nguyentranducluong7t2g2	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Trần Đức Lương	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	d0222c30-f003-4f6c-bf98-6825b60d003d	0	\N	\N
ee77be2e-9496-4f88-8a8d-f8a80c22da25	nguyenhothikhanhlyyd973	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Thị Khánh Ly	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	82ffd4dc-2ea9-47c5-8530-1bcbebfe7a18	0	\N	\N
b9e625c2-b6f3-458a-bd57-3190ef3fd915	nguyennguyenhoangbaominh4lzjo	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Hoàng Bảo Minh	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	b62028d5-9b47-4476-8fba-d4bfc62a9dd5	0	\N	\N
c0abac25-29e0-4dd3-a6a5-873391c07ea5	nguyenhothungajwt62	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Thu Nga	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	62ad74b4-19b8-44ed-a72f-cffa3ec88d90	0	\N	\N
416380e1-d93b-4c05-a801-a4c58c222873	nguyentrinhthihangnga4i5k1	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Trịnh Thị Hằng Nga	DV	2026-08-19 14:22:40.425401+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.425401+00	abe14198-7285-4639-9a5a-dccebb61a5eb	0	\N	\N
35239b13-0a76-4a3a-ba07-26bcf14daaba	nguyennguyenlucngansyisy	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Lục Ngạn	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	15545814-0567-4824-8255-6f4da1cd63d6	0	\N	\N
d2d2ea8c-e490-4254-b1ee-a3f80b574586	nguyenlehoangmyngoc13n5i	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lê Hoàng Mỹ Ngọc	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	9c90c250-09fa-4f99-a1c3-502c943945ce	0	\N	\N
b5370237-462d-41fb-bfc5-abea9b7bdacf	nguyenlethibaongoczoq5v	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lê Thị Bảo Ngọc	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	8a1a9971-689e-425b-8958-fb342684020c	0	\N	\N
599f8f54-8947-40d7-9001-fb4877c04870	nguyencaoanhnhani1xgm	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Cao Anh Nhân	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	132de78f-f29a-4b68-9726-a98367425ab1	0	\N	\N
33b6ab4e-29ff-4194-a325-b4c54f4d65fb	nguyenlevothanhnhat3wbwa	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lê Võ Thanh Nhật	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	cd628b22-7416-4888-8ae5-c97bfc46280a	0	\N	\N
5dfa9bad-9070-4889-ad1b-c06b5ddc8070	nguyendangthithuphuonglngtm	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Đặng Thị Thu Phương	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	fcb9faa7-0d0c-4eed-b84f-5c11152ad276	0	\N	\N
c64abddc-ae26-4568-bf96-5100c581e0db	nguyendobaoquangrpiwm	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Đỗ Bảo Quang	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	64fae51a-8d7e-46a2-bdf9-41e678edadbc	0	\N	\N
d5fb82ef-2a36-4e8f-8ad8-182e9575003b	nguyenvohanhthaoktlgj	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Võ Hạnh Thảo	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	756c505d-8d9a-4334-97a9-c4badc77a6d5	0	\N	\N
4563050d-5eb6-406f-b8da-881c1423c517	nguyentranhongthek5lwg	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Trần Hồng Thế	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	996643f5-ca6d-4636-a6e4-24b619b18d50	0	\N	\N
a3bcdda2-6495-4b5f-b6d0-ae48c408d73e	nguyenduongducthinh9opxt	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Dương Đức Thịnh	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	aa20250d-03d5-4a33-b996-dbcb56f21d50	0	\N	\N
015ca357-37c2-4a76-a594-382e876cd3cd	nguyenphanngocthinhdrt1t	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Phan Ngọc Thịnh	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	e58f30ba-2bcb-4cb7-86ba-92958e6b98b5	0	\N	\N
7bcc8158-1918-4926-87be-b834dcf3ea6c	nguyenbuithilythu3b55a	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Bùi Thị Lý Thu	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	ea0169ae-885f-4c70-b3b8-d2043dce9bc0	0	\N	\N
7191d584-0779-4ed2-97e9-c12a7e4c6dcb	nguyenhonguyenkhanhtrangej87c	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Nguyễn Khánh Trang	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	7bddb6b5-c31b-4294-b3d7-7c43c9499f9e	0	\N	\N
db7854ab-3825-40ea-9e99-f33105568330	nguyenhothithuytrang98oit	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Hồ Thị Thùy Trang	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	47469c02-bf2a-4a7e-a9c2-7bc1f65a678f	0	\N	\N
f46cb549-598d-4d21-be0c-4bd26999ff70	nguyenlethithuytrang3r372	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Lê Thị Thùy Trang	DV	2026-08-19 14:22:40.679133+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.679133+00	81d9ce82-6ea1-4fcd-8355-4d6f2005fd0a	0	\N	\N
f21ef2d2-617e-41ae-bf3c-6fa7c4399c54	nguyennguyenthihuyentranghicmt	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Thị Huyền Trang	DV	2026-08-19 14:22:40.850163+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.850163+00	1a9ffd96-d050-4717-9c76-32711f665dfd	0	\N	\N
928cd440-0953-44ec-a679-8e91a1c67cbf	nguyennguyentranhuyentrangn7xzz	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Trần Huyền Trang	DV	2026-08-19 14:22:40.850163+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.850163+00	9bb5aac9-ca5d-4821-95f3-e5809a20b292	0	\N	\N
3b63896d-7bde-4314-991f-12818b3f81da	nguyennguyenquoctrong25sy2	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Nguyễn Quốc Trọng	DV	2026-08-19 14:22:40.850163+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.850163+00	2dd1edeb-ba60-422c-af39-51ec2572fc69	0	\N	\N
d66f5830-db46-4826-ba06-85790a6b0334	nguyendoantuongvyyljwv	$2b$10$5Ek7YGfwPwqoJbMemRPL6OmDYA/rkJ9r2DUkuKh3W3GIfyNZ.UACC	Nguyễn Đoàn Tường Vy	DV	2026-08-19 14:22:40.850163+00	1aa48c10-6d5d-4c33-93aa-7edf3f7f7122	2026-08-19 14:22:40.850163+00	437551b2-5236-46f0-a1e0-6aee292625c3	0	\N	\N
\.


--
-- Data for Name: theodoi360; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."theodoi360" ("id", "nguoi_to_cao_id", "doan_vien_vi_pham_id", "tieu_chi_id", "chi_tiet_vi_pham", "danh_sach_hinh_anh", "url_video", "trang_thai", "nam_hoc_id", "tuan_id", "ngay_vi_pham", "ngay_tao", "hoc_ky", "phan_hoi_bi_to_cao", "phan_hoi_lop", "minh_chung_drive") FROM stdin;
b2fd5de2-68cc-4777-ae97-51832e94792d	21735797-3a80-4b5c-b8af-f30fe139af5d	fe4ff85d-5eb8-4a3e-902c-4a6a6fecab20	c7f841e9-00c3-4bb3-abcf-c93357130ed5	lỗi	["https://pub-cfc46e010f594a758fd2d73f3c153f0a.r2.dev/TheoDoi360/2026-2027/HK1/T1/10A1/NguyenNguyenCongHau/2026-08-06/Cuptiet/NguyenNguyenCongHau_10A1_2026-2027_HK1_T1_NEW_hinh1_dce6.jpg"]	\N	cho_duyet	ad40294c-5077-4af0-a9f1-421e5ffe1c38	cc9321ed-f5e6-42c6-9657-6c6aa2c34af3	2026-08-06	2026-08-06 03:00:38.967426+00	HK1			\N
\.


--
-- Data for Name: thongbao_hethong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_hethong" ("id", "title", "content", "sender", "target_role", "target_chidoan_id", "target_user_id", "created_at", "read_by") FROM stdin;
\.


--
-- Data for Name: thongbao_riengbiet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."thongbao_riengbiet" ("id", "namhoc_id", "sender_id", "sender_name", "sender_role", "title", "content", "attachments", "target_roles", "target_chidoan_ids", "start_at", "end_at", "created_at", "updated_at", "read_by") FROM stdin;
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
805c6029-e890-4618-9e6a-acbd9a06503c	CD01	Điểm 10		Thành tích	0	3		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
b1a040c9-a826-4241-a808-b9e8d139c1e0	CD02	Điểm 9		Thành tích	0	2		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
e67c0d64-6b1b-4f21-b913-6b6eaac68242	CD03	Nhặt được của rơi		Thành tích	0	5		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
355d4a09-df27-47fe-8194-b93ec568fe19	TC01	Đi học muộn2		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
c7f841e9-00c3-4bb3-abcf-c93357130ed5	TC02	Cúp tiết		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
c9f66eee-3039-45b0-8059-d41088d1f317	TC03	Cúp chào cờ		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
f92b79b4-78cc-4860-ba3a-9b7767cb00bd	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
67711bb1-e078-4cfd-aa31-0b8d5f8189ef	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
06ab1134-4697-4522-9b89-dd16ed88213b	TC06	Không sơ vin		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
b0b4e38e-3f43-4b33-a533-490de431864d	TC07	Không bảng tên		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
1fe037e6-fc00-446a-be1d-06596358cb19	TC08	Sai đồng phục		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
9cdb027f-0437-4d3a-a793-4fc7bf278ad2	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
20b5a550-2b10-46aa-baaa-c9148d712fb1	TC10	Không quai dép		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
1bbb258e-9985-48d0-9cff-34d0ee92f8ca	TC11	Đi dép lê		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
9513bd1b-0d6c-4e46-a282-56b17a426a5e	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
1948a945-b747-4ae5-8e49-ffc37c962a00	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
982592ec-ec9e-4562-95ee-58ddb4c20b27	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
156a6561-1ba1-49a0-ae50-339c645be44e	TC15	Sơn móng tay		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
8f254a95-2d7e-487f-92a3-6041b42186ee	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
264f81b3-3b72-4a33-a46f-473f0d8fcffe	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
5940ba95-59a2-4043-a41a-5846bdc63c8c	TC18	chở quá số người qui định		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
156fa105-1b14-47b6-8f2d-8ffb251cc9b6	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
4242f94b-913d-4917-9530-4524eff98af0	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
07d5ae5a-faa5-4dee-ab60-5922a43ceae9	TC21	Hút thuốc lá		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
f766ea19-c686-48c2-9536-4f1a96253de2	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
7a15bc65-9ee7-4dd8-8c35-ea4057987063	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
467e1373-ccb7-4b43-9eff-b9598dcd53bc	TC24	Có thái độ vô lễ với CB, CNV nhà trường:		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
df8dff66-b017-41b0-b6a5-c7eecbf3ea2e	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
0b2b6e2b-048e-4633-950c-855d72b3783c	TC26	Vệ sinh muộn		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
fc5f1739-0fe3-41a7-97be-3875ffc4196f	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
b7560521-3781-4102-b0ab-59f7c4514088	TC28	Học sinh vứt rác không đúng qui định		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
34d6e285-94c4-4720-99e9-219febef8c20	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
6eeae8c7-5ebd-4e56-b6b3-280a6187d565	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
818ce83d-1c36-4744-84ea-bbdf5ae4c90f	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
2e9ad26a-c72d-4f02-855c-69801c085429	TC32	Không cất ghế ngồi chào cờ		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
edc802b5-e03e-47f5-807b-bddf5ba2207a	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
6648bae5-b7d2-401e-8f60-739da2e21dff	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
ff22bb78-f90e-44d6-89aa-1a364ad91d21	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
2a9ecc80-e3a7-4d22-bf5e-cd837ce54ad7	TC36	Học sinh vào lớp muộn trong giữa các tiết học		Vi phạm	0.5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
cc03dafd-7be8-487f-99b6-da25da3c5443	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
40c0858b-8e1d-4cfc-9ad2-d49b20a7b60b	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
b8a4243e-10ca-4901-a5ce-ff5281c29dae	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
1279ac41-cd79-48b4-b637-3b747f4724e4	TC40	Đi chấm trễ		Vi phạm	2	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
da3db98a-596f-4d9c-b59f-23585ec09e3e	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
ccb1a599-199c-41c0-8cf1-e1767ca7e69c	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
4f1d2634-203c-4e41-afb0-497cf585f4a6	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
bc5da08e-4845-4a58-b0a9-9b1ba9a60a4d	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
c0c234a1-0c6f-499e-8941-0fab34aeb20d	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
8db0a463-7043-424e-9bd0-873d171fc424	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
d596d44c-bffc-44b1-8118-8b1ce63c4626	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
bdb83358-8849-47aa-bd6d-85e212391749	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
07220f48-4ab1-469c-bac6-51e9a00df80e	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
1ca2ddda-4bf5-4615-9f7a-4734e5a9f4b0	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
f99df07e-db73-4089-9fbf-1b478d25cc38	TC52	Không đi chấm		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
700a52a1-97f8-4172-b72b-97c95c208014	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
a08ad360-1a4c-4ae6-90d5-9dca4b7f23fc	TC56	Cúp 1 tiết		Vi phạm	5	0		2026-08-06 00:20:31.629187+00	HK1	ad40294c-5077-4af0-a9f1-421e5ffe1c38	2026-08-06 00:20:31.629187+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
cc9321ed-f5e6-42c6-9657-6c6aa2c34af3	ad40294c-5077-4af0-a9f1-421e5ffe1c38	HK1	1	2026-08-05	2026-12-19	t	f	2026-08-05 15:18:28.824375+00		2026-08-05 15:19:16.280331+00
\.


--
-- Data for Name: vanban_doan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."vanban_doan" ("id", "category", "title", "drive_link", "updated_at", "updated_by") FROM stdin;
04198012-9049-4ec8-88cb-2d7b50feb545	ke_hoach	Kế hoạch		2026-08-18 04:38:23.891619+00	
223c3ad8-1f4e-4411-8554-e3b5a78c66b4	thong_bao	Thông báo		2026-08-18 04:38:23.891619+00	
340b64c2-7f9a-4599-bbda-79bf5d3eff9e	nghi_quyet	Nghị quyết		2026-08-18 04:38:23.891619+00	
26ef81a4-3760-41d4-894b-64ae9d549ec3	bao_cao	Báo cáo		2026-08-18 04:38:23.891619+00	
09f37d4f-d033-4bda-b354-e23f67e0af30	tai_chinh	Tài chính		2026-08-18 04:38:23.891619+00	
ca028877-619e-4174-bef8-d9f940e55e43	van_ban_khac	Văn bản khác		2026-08-18 04:38:23.891619+00	
\.


--
-- Data for Name: xet_thidua; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."xet_thidua" ("id", "namhoc_id", "hoc_ky", "chidoan_id", "tong_diem_cham_tuan", "tieuchi_1", "tieuchi_2", "tieuchi_3", "tieuchi_4", "tieuchi_5", "tieuchi_6", "tieuchi_7", "tieuchi_8", "tieuchi_9", "tieuchi_10", "tong_diem", "xep_hang", "danh_hieu_thi_dua", "ghi_chu", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_16; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_16" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_17; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_17" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_18; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_18" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_19; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_19" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_20; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_20" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_21; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_21" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: messages_2026_08_22; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."messages_2026_08_22" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id", "binary_payload") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-08-05 13:33:18
20211116045059	2026-08-05 13:33:18
20211116050929	2026-08-05 13:33:18
20211116051442	2026-08-05 13:33:18
20211116212300	2026-08-05 13:33:18
20211116213355	2026-08-05 13:33:18
20211116213934	2026-08-05 13:33:18
20211116214523	2026-08-05 13:33:18
20211122062447	2026-08-05 13:33:18
20211124070109	2026-08-05 13:33:18
20211202204204	2026-08-05 13:33:18
20211202204605	2026-08-05 13:33:18
20211210212804	2026-08-05 13:33:18
20211228014915	2026-08-05 13:33:18
20220107221237	2026-08-05 13:33:18
20220228202821	2026-08-05 13:33:18
20220312004840	2026-08-05 13:33:18
20220603231003	2026-08-05 13:33:18
20220603232444	2026-08-05 13:33:18
20220615214548	2026-08-05 13:33:18
20220712093339	2026-08-05 13:33:18
20220908172859	2026-08-05 13:33:18
20220916233421	2026-08-05 13:33:18
20230119133233	2026-08-05 13:33:18
20230128025114	2026-08-05 13:33:18
20230128025212	2026-08-05 13:33:18
20230227211149	2026-08-05 13:33:18
20230228184745	2026-08-05 13:33:18
20230308225145	2026-08-05 13:33:18
20230328144023	2026-08-05 13:33:18
20231018144023	2026-08-05 13:33:18
20231204144023	2026-08-05 13:33:18
20231204144024	2026-08-05 13:33:18
20231204144025	2026-08-05 13:33:18
20240108234812	2026-08-05 13:33:18
20240109165339	2026-08-05 13:33:18
20240227174441	2026-08-05 13:33:18
20240311171622	2026-08-05 13:33:18
20240321100241	2026-08-05 13:33:18
20240401105812	2026-08-05 13:33:18
20240418121054	2026-08-05 13:33:18
20240523004032	2026-08-05 13:33:18
20240618124746	2026-08-05 13:33:18
20240801235015	2026-08-05 13:33:18
20240805133720	2026-08-05 13:33:18
20240827160934	2026-08-05 13:33:18
20240919163303	2026-08-05 13:33:18
20240919163305	2026-08-05 13:33:18
20241019105805	2026-08-05 13:33:18
20241030150047	2026-08-05 13:33:18
20241108114728	2026-08-05 13:33:18
20241121104152	2026-08-05 13:33:18
20241130184212	2026-08-05 13:33:18
20241220035512	2026-08-05 13:33:18
20241220123912	2026-08-05 13:33:18
20241224161212	2026-08-05 13:33:18
20250107150512	2026-08-05 13:33:18
20250110162412	2026-08-05 13:33:18
20250123174212	2026-08-05 13:33:18
20250128220012	2026-08-05 13:33:18
20250506224012	2026-08-05 13:33:18
20250523164012	2026-08-05 13:33:18
20250714121412	2026-08-05 13:33:18
20250905041441	2026-08-05 13:33:18
20251103001201	2026-08-05 13:33:18
20251120212548	2026-08-05 13:33:18
20251120215549	2026-08-05 13:33:18
20260218120000	2026-08-05 13:33:18
20260326120000	2026-08-05 13:33:18
20260514120000	2026-08-05 13:33:18
20260527120000	2026-08-05 13:33:18
20260528120000	2026-08-05 13:33:18
20260603120000	2026-08-05 13:33:18
20260605120000	2026-08-05 13:33:18
20260606110000	2026-08-05 13:33:18
20260616120000	2026-08-05 13:33:18
20260624120000	2026-08-05 13:33:18
20260626120000	2026-08-05 13:33:18
20260706120000	2026-08-05 13:33:18
20260707120000	2026-08-05 13:33:18
20260709120000	2026-08-05 13:33:18
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_realtime_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter", "selected_columns") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-08-05 13:33:25.118818
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-08-05 13:33:25.125509
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-08-05 13:33:25.128693
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-08-05 13:33:25.145523
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-08-05 13:33:25.161973
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-08-05 13:33:25.165995
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-08-05 13:33:25.171953
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-08-05 13:33:25.176419
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-08-05 13:33:25.181447
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-08-05 13:33:25.186607
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-08-05 13:33:25.189793
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-08-05 13:33:25.193043
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-08-05 13:33:25.196758
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-08-05 13:33:25.200608
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-08-05 13:33:25.204021
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-08-05 13:33:25.236935
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-08-05 13:33:25.241468
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-08-05 13:33:25.244882
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-08-05 13:33:25.251773
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-08-05 13:33:25.256784
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-08-05 13:33:25.260174
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-08-05 13:33:25.265726
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-08-05 13:33:25.279151
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-08-05 13:33:25.293317
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-08-05 13:33:25.296482
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-08-05 13:33:25.299191
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-08-05 13:33:25.30202
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-08-05 13:33:25.304283
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-08-05 13:33:25.306642
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-08-05 13:33:25.308919
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-08-05 13:33:25.311502
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-08-05 13:33:25.313743
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-08-05 13:33:25.316343
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-08-05 13:33:25.32032
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-08-05 13:33:25.322888
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-08-05 13:33:25.326257
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-08-05 13:33:25.329577
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-08-05 13:33:25.332122
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-08-05 13:33:25.337833
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-08-05 13:33:25.345796
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-08-05 13:33:25.348546
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-08-05 13:33:25.351215
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-08-05 13:33:25.353641
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-08-05 13:33:25.356046
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-08-05 13:33:25.35876
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-08-05 13:33:25.3621
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-08-05 13:33:25.374941
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-08-05 13:33:25.379061
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-08-05 13:33:25.383706
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-08-05 13:33:25.403914
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-08-05 13:33:25.407985
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-08-05 13:33:26.172508
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-08-05 13:33:26.17434
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-08-05 13:33:26.183367
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-08-05 13:33:26.187531
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-08-05 13:33:26.189144
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-08-05 13:33:26.197102
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-08-05 13:33:26.204424
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-08-05 13:33:26.207399
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-08-05 13:33:26.211358
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-08-05 13:33:26.214819
61	mark-filename-immutable	fe0096517ae9d60aaec1d110172ba9036dc66bb7	2026-08-15 08:12:47.197193
62	object-versioning-core	0b855f00ff3be0bfca91efee02a9858912491a9a	2026-08-21 00:02:53.370097
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata", "archived_at", "is_delete_marker", "is_versioned") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 20, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 114, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_realtime_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: gio_hoc_tap gio_hoc_tap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "gio_hoc_tap_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_endpoint_key" UNIQUE ("endpoint");


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."push_subscriptions"
    ADD CONSTRAINT "push_subscriptions_pkey" PRIMARY KEY ("id");


--
-- Name: ql_baocao ql_baocao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "ql_baocao_pkey" PRIMARY KEY ("id");


--
-- Name: ql_nop_bc ql_nop_bc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "ql_nop_bc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: theodoi360 theodoi360_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_hethong thongbao_hethong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_hethong"
    ADD CONSTRAINT "thongbao_hethong_pkey" PRIMARY KEY ("id");


--
-- Name: thongbao_riengbiet thongbao_riengbiet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."thongbao_riengbiet"
    ADD CONSTRAINT "thongbao_riengbiet_pkey" PRIMARY KEY ("id");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: cauhinh_tieuchi_xet_thidua unique_cauhinh_namhoc_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "unique_cauhinh_namhoc_hocky" UNIQUE ("namhoc_id", "hoc_ky");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: gio_hoc_tap unique_chidoan_tuan_namhoc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "unique_chidoan_tuan_namhoc" UNIQUE ("chidoan_id", "tuan_id", "namhoc_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: xet_thidua unique_xet_thidua_chidoan_hocky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "unique_xet_thidua_chidoan_hocky" UNIQUE ("namhoc_id", "hoc_ky", "chidoan_id");


--
-- Name: vanban_doan vanban_doan_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."vanban_doan"
    ADD CONSTRAINT "vanban_doan_category_key" UNIQUE ("category");


--
-- Name: vanban_doan vanban_doan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."vanban_doan"
    ADD CONSTRAINT "vanban_doan_pkey" PRIMARY KEY ("id");


--
-- Name: xet_thidua xet_thidua_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_pkey" PRIMARY KEY ("id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_16 messages_2026_08_16_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_16"
    ADD CONSTRAINT "messages_2026_08_16_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_17 messages_2026_08_17_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_17"
    ADD CONSTRAINT "messages_2026_08_17_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_18 messages_2026_08_18_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_18"
    ADD CONSTRAINT "messages_2026_08_18_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_19 messages_2026_08_19_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_19"
    ADD CONSTRAINT "messages_2026_08_19_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_20 messages_2026_08_20_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_20"
    ADD CONSTRAINT "messages_2026_08_20_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_21 messages_2026_08_21_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_21"
    ADD CONSTRAINT "messages_2026_08_21_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_08_22 messages_2026_08_22_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_08_22"
    ADD CONSTRAINT "messages_2026_08_22_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages messages_payload_exclusive; Type: CHECK CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages"
    ADD CONSTRAINT "messages_payload_exclusive" CHECK ((("payload" IS NULL) OR ("binary_payload" IS NULL))) NOT VALID;


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: idx_users_created_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_created_at_desc" ON "auth"."users" USING "btree" ("created_at" DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_email" ON "auth"."users" USING "btree" ("email");


--
-- Name: idx_users_last_sign_in_at_desc; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_last_sign_in_at_desc" ON "auth"."users" USING "btree" ("last_sign_in_at" DESC);


--
-- Name: idx_users_name; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_users_name" ON "auth"."users" USING "btree" ((("raw_user_meta_data" ->> 'name'::"text"))) WHERE (("raw_user_meta_data" ->> 'name'::"text") IS NOT NULL);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_cauhinh_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_cauhinh_thidua_namhoc_hocky" ON "public"."cauhinh_tieuchi_xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: idx_chamdiem_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_hocky" ON "public"."chamdiem" USING "btree" ("hocky");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_lopcham_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_lopcham_chamlop" ON "public"."chamdiem" USING "btree" ("lopcham", "chamlop");


--
-- Name: idx_chamdiem_optimization_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chamlop" ON "public"."chamdiem" USING "btree" ("chamlop");


--
-- Name: idx_chamdiem_optimization_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_optimization_namhoc_hocky_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_hocky_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_chamdiem_optimization_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_optimization_namhoc_tuan" ON "public"."chamdiem" USING "btree" ("namhoc", "tuan");


--
-- Name: idx_chamdiem_thongke; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thongke" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan", "chamlop");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_ql_nop_bc_baocao; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_baocao" ON "public"."ql_nop_bc" USING "btree" ("ql_bao_cao_id");


--
-- Name: idx_ql_nop_bc_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_chidoan" ON "public"."ql_nop_bc" USING "btree" ("chi_doan_id");


--
-- Name: idx_ql_nop_bc_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ql_nop_bc_doanvien" ON "public"."ql_nop_bc" USING "btree" ("doanvien_id");


--
-- Name: idx_qlchidoan_optimization_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_optimization_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_doanvien_id" ON "public"."taikhoan" USING "btree" ("doanvien_id");


--
-- Name: idx_taikhoan_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_role" ON "public"."taikhoan" USING "btree" ("role");


--
-- Name: idx_taikhoan_username_lower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_username_lower" ON "public"."taikhoan" USING "btree" ("lower"("username"));


--
-- Name: idx_theodoi360_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_doanvien" ON "public"."theodoi360" USING "btree" ("doan_vien_vi_pham_id");


--
-- Name: idx_theodoi360_namhoc_tuan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_theodoi360_namhoc_tuan" ON "public"."theodoi360" USING "btree" ("nam_hoc_id", "tuan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_optimization_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_optimization_namhoc_hocky" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_xet_thidua_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_chidoan" ON "public"."xet_thidua" USING "btree" ("chidoan_id");


--
-- Name: idx_xet_thidua_namhoc_hocky; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_xet_thidua_namhoc_hocky" ON "public"."xet_thidua" USING "btree" ("namhoc_id", "hoc_ky");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_16_inserted_at_topic_idx" ON "realtime"."messages_2026_08_16" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_17_inserted_at_topic_idx" ON "realtime"."messages_2026_08_17" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_18_inserted_at_topic_idx" ON "realtime"."messages_2026_08_18" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_19_inserted_at_topic_idx" ON "realtime"."messages_2026_08_19" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_20_inserted_at_topic_idx" ON "realtime"."messages_2026_08_20" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_21_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_21_inserted_at_topic_idx" ON "realtime"."messages_2026_08_21" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_08_22_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_2026_08_22_inserted_at_topic_idx" ON "realtime"."messages_2026_08_22" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_selec; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_selec" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter", COALESCE("selected_columns", '{}'::"text"[]));


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_08_16_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_16_inserted_at_topic_idx";


--
-- Name: messages_2026_08_16_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_16_pkey";


--
-- Name: messages_2026_08_17_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_17_inserted_at_topic_idx";


--
-- Name: messages_2026_08_17_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_17_pkey";


--
-- Name: messages_2026_08_18_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_18_inserted_at_topic_idx";


--
-- Name: messages_2026_08_18_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_18_pkey";


--
-- Name: messages_2026_08_19_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_19_inserted_at_topic_idx";


--
-- Name: messages_2026_08_19_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_19_pkey";


--
-- Name: messages_2026_08_20_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_20_inserted_at_topic_idx";


--
-- Name: messages_2026_08_20_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_20_pkey";


--
-- Name: messages_2026_08_21_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_21_inserted_at_topic_idx";


--
-- Name: messages_2026_08_21_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_21_pkey";


--
-- Name: messages_2026_08_22_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_08_22_inserted_at_topic_idx";


--
-- Name: messages_2026_08_22_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_08_22_pkey";


--
-- Name: taikhoan trg_1_kiem_tra_an_ninh_taikhoan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_1_kiem_tra_an_ninh_taikhoan" BEFORE INSERT OR DELETE OR UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"();


--
-- Name: taikhoan trg_2_tu_dong_bam_mat_khau_taikhoan; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_2_tu_dong_bam_mat_khau_taikhoan" BEFORE INSERT OR UPDATE OF "password" ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"();


--
-- Name: taikhoan trg_3_dong_bo_taikhoan_sang_auth_users; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trg_3_dong_bo_taikhoan_sang_auth_users" AFTER INSERT OR DELETE OR UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"();


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: cauhinh_tieuchi_xet_thidua cauhinh_tieuchi_xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."cauhinh_tieuchi_xet_thidua"
    ADD CONSTRAINT "cauhinh_tieuchi_xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_chidoan" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_namhoc" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: gio_hoc_tap fk_giohoctap_tuan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."gio_hoc_tap"
    ADD CONSTRAINT "fk_giohoctap_tuan" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id") ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ql_baocao fk_ql_baocao_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_baocao"
    ADD CONSTRAINT "fk_ql_baocao_namhoc" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: ql_nop_bc fk_ql_nop_bc_baocao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_baocao" FOREIGN KEY ("ql_bao_cao_id") REFERENCES "public"."ql_baocao"("id") ON DELETE CASCADE;


--
-- Name: ql_nop_bc fk_ql_nop_bc_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_chidoan" FOREIGN KEY ("chi_doan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE SET NULL;


--
-- Name: ql_nop_bc fk_ql_nop_bc_doanvien; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ql_nop_bc"
    ADD CONSTRAINT "fk_ql_nop_bc_doanvien" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON DELETE SET NULL;


--
-- Name: theodoi360 theodoi360_doan_vien_vi_pham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_doan_vien_vi_pham_fkey" FOREIGN KEY ("doan_vien_vi_pham_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_nam_hoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nam_hoc_fkey" FOREIGN KEY ("nam_hoc_id") REFERENCES "public"."namhoc"("id");


--
-- Name: theodoi360 theodoi360_nguoi_to_cao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_nguoi_to_cao_fkey" FOREIGN KEY ("nguoi_to_cao_id") REFERENCES "public"."doanvien"("id");


--
-- Name: theodoi360 theodoi360_tieu_chi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tieu_chi_fkey" FOREIGN KEY ("tieu_chi_id") REFERENCES "public"."tieuchitd"("id");


--
-- Name: theodoi360 theodoi360_tuan_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."theodoi360"
    ADD CONSTRAINT "theodoi360_tuan_fkey" FOREIGN KEY ("tuan_id") REFERENCES "public"."tuanhoc"("id");


--
-- Name: xet_thidua xet_thidua_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: xet_thidua xet_thidua_namhoc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."xet_thidua"
    ADD CONSTRAINT "xet_thidua_namhoc_id_fkey" FOREIGN KEY ("namhoc_id") REFERENCES "public"."namhoc"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: vanban_doan Admin có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin có full quyền" ON "public"."vanban_doan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text"])));


--
-- Name: taikhoan Admin toàn quyền quản trị bảng taikhoan; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin toàn quyền quản trị bảng taikhoan" ON "public"."taikhoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text"])));


--
-- Name: cauhinh_tieuchi_xet_thidua Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: doanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."doanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: dotptdoanvien Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."dotptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: namhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."namhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: phancong Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."phancong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ql_baocao Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."ql_baocao" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: qlchidoan Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."qlchidoan" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tieuchitd Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tieuchitd" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: tuanhoc Admin và BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin và BTV có full quyền" ON "public"."tuanhoc" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: thongbao_hethong Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."thongbao_hethong" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: xet_thidua Admin, BTV có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV có full quyền" ON "public"."xet_thidua" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text"])));


--
-- Name: ptdoanvien Admin, BTV, BCH có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BCH có full quyền" ON "public"."ptdoanvien" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BCH'::"text"])));


--
-- Name: thongbao_riengbiet Admin, BTV, BGH, GVCN có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, BGH, GVCN có full quyền" ON "public"."thongbao_riengbiet" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'BGH'::"text", 'GVCN'::"text"])));


--
-- Name: chamdiem Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."chamdiem" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: gio_hoc_tap Admin, BTV, NC có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin, BTV, NC có full quyền" ON "public"."gio_hoc_tap" TO "authenticated" USING (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"]))) WITH CHECK (("public"."get_auth_role"() = ANY (ARRAY['Admin'::"text", 'BTV'::"text", 'NC'::"text"])));


--
-- Name: doanvien BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."doanvien" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: qlchidoan BCH chỉ được phép sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "BCH chỉ được phép sửa" ON "public"."qlchidoan" FOR UPDATE TO "authenticated" USING (("public"."get_auth_role"() = 'BCH'::"text")) WITH CHECK (("public"."get_auth_role"() = 'BCH'::"text"));


--
-- Name: duytricsdl Cho phép mọi người cập nhật duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người cập nhật duytricsdl" ON "public"."duytricsdl" FOR UPDATE USING (true) WITH CHECK (true);


--
-- Name: duytricsdl Cho phép mọi người xem duytricsdl; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép mọi người xem duytricsdl" ON "public"."duytricsdl" FOR SELECT USING (true);


--
-- Name: phanquyen Cho phép xem bảng phân quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem bảng phân quyền" ON "public"."phanquyen" FOR SELECT TO "authenticated" USING (true);


--
-- Name: qlchidoan Cho phép xem danh sách chi đoàn; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách chi đoàn" ON "public"."qlchidoan" FOR SELECT USING (true);


--
-- Name: namhoc Cho phép xem danh sách năm học; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách năm học" ON "public"."namhoc" FOR SELECT USING (true);


--
-- Name: tuanhoc Cho phép xem danh sách tuần học; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách tuần học" ON "public"."tuanhoc" FOR SELECT USING (true);


--
-- Name: taikhoan Cho phép xem danh sách tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép xem danh sách tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING ((("public"."get_auth_role"() = ANY (ARRAY['admin'::"text", 'btv'::"text", 'bgh'::"text"])) OR ("id" = "auth"."uid"()) OR ("lower"("username") = "lower"("split_part"(COALESCE("auth"."email"(), ''::"text"), '@'::"text", 1)))));


--
-- Name: github_settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."github_settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: phanquyen Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."phanquyen" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: settings Chỉ Admin được sửa; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Chỉ Admin được sửa" ON "public"."settings" TO "authenticated" USING (("public"."get_auth_role"() = 'Admin'::"text")) WITH CHECK (("public"."get_auth_role"() = 'Admin'::"text"));


--
-- Name: cauhinh_tieuchi_xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."cauhinh_tieuchi_xet_thidua" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: chamdiem Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."chamdiem" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: doanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."doanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: dotptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."dotptdoanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: gio_hoc_tap Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."gio_hoc_tap" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: github_settings Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."github_settings" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: phancong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."phancong" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ptdoanvien Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ptdoanvien" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ql_baocao Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."ql_baocao" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: settings Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."settings" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: thongbao_hethong Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_hethong" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: thongbao_riengbiet Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."thongbao_riengbiet" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: tieuchitd Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."tieuchitd" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: vanban_doan Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."vanban_doan" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: xet_thidua Mọi tài khoản đều được XEM; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Mọi tài khoản đều được XEM" ON "public"."xet_thidua" FOR SELECT TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: taikhoan Zero-Trust: Sửa dữ liệu cá nhân; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Zero-Trust: Sửa dữ liệu cá nhân" ON "public"."taikhoan" FOR UPDATE TO "authenticated" USING ((("id" = "auth"."uid"()) AND ((( SELECT "count"(*) AS "count"
   FROM "auth"."mfa_factors"
  WHERE (("mfa_factors"."user_id" = "auth"."uid"()) AND ("mfa_factors"."status" = 'verified'::"auth"."factor_status"))) = 0) OR (("auth"."jwt"() ->> 'aal'::"text") = 'aal2'::"text")))) WITH CHECK (("id" = "auth"."uid"()));


--
-- Name: taikhoan Zero-Trust: Xem dữ liệu tài khoản; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Zero-Trust: Xem dữ liệu tài khoản" ON "public"."taikhoan" FOR SELECT TO "authenticated" USING (((("id" = "auth"."uid"()) OR ("upper"((("auth"."jwt"() -> 'user_metadata'::"text") ->> 'role'::"text")) = 'ADMIN'::"text")) AND ((( SELECT "count"(*) AS "count"
   FROM "auth"."mfa_factors"
  WHERE (("mfa_factors"."user_id" = "auth"."uid"()) AND ("mfa_factors"."status" = 'verified'::"auth"."factor_status"))) = 0) OR (("auth"."jwt"() ->> 'aal'::"text") = 'aal2'::"text"))));


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: cauhinh_tieuchi_xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."cauhinh_tieuchi_xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: duytricsdl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."duytricsdl" ENABLE ROW LEVEL SECURITY;

--
-- Name: gio_hoc_tap; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."gio_hoc_tap" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: push_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."push_subscriptions" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_baocao; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_baocao" ENABLE ROW LEVEL SECURITY;

--
-- Name: ql_nop_bc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ql_nop_bc" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: theodoi360; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."theodoi360" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_hethong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_hethong" ENABLE ROW LEVEL SECURITY;

--
-- Name: thongbao_riengbiet; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."thongbao_riengbiet" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: vanban_doan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."vanban_doan" ENABLE ROW LEVEL SECURITY;

--
-- Name: xet_thidua; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."xet_thidua" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."activity_logs" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: duytricsdl Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."duytricsdl" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: push_subscriptions Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."push_subscriptions" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: ql_nop_bc Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."ql_nop_bc" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: theodoi360 Đăng nhập thành công có full quyền; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Đăng nhập thành công có full quyền" ON "public"."theodoi360" TO "authenticated" USING (("public"."get_auth_role"() IS NOT NULL)) WITH CHECK (("public"."get_auth_role"() IS NOT NULL));


--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "fn_dong_bo_taikhoan_sang_auth_users"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_dong_bo_taikhoan_sang_auth_users"() TO "service_role";


--
-- Name: FUNCTION "fn_kiem_tra_an_ninh_taikhoan"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_kiem_tra_an_ninh_taikhoan"() TO "service_role";


--
-- Name: FUNCTION "fn_tu_dong_bam_mat_khau_taikhoan"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "anon";
GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."fn_tu_dong_bam_mat_khau_taikhoan"() TO "service_role";


--
-- Name: FUNCTION "get_auth_chidoan_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_chidoan_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_doanvien_id"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_doanvien_id"() TO "service_role";


--
-- Name: FUNCTION "get_auth_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_auth_role"() TO "service_role";


--
-- Name: FUNCTION "get_secure_role"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_secure_role"() TO "service_role";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_delete_auth_users_by_usernames"("p_usernames" "text"[]) TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_tao_tai_khoan_an_toan"("p_username" "text", "p_password" "text", "p_fullname" "text", "p_role" "text", "p_chidoan_id" "uuid", "p_doanvien_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "save_user_backup_codes"("p_encrypted_codes" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."save_user_backup_codes"("p_encrypted_codes" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "verify_and_consume_backup_code"("p_code" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."verify_and_consume_backup_code"("p_code" "text") TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text", "negate" boolean) TO "service_role";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send_binary"("payload" "bytea", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "wal2json_escape_identifier"("name" "text"); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."wal2json_escape_identifier"("name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "cauhinh_tieuchi_xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."cauhinh_tieuchi_xet_thidua" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "gio_hoc_tap"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "anon";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "authenticated";
GRANT ALL ON TABLE "public"."gio_hoc_tap" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "push_subscriptions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."push_subscriptions" TO "anon";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "authenticated";
GRANT ALL ON TABLE "public"."push_subscriptions" TO "service_role";


--
-- Name: TABLE "ql_baocao"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_baocao" TO "anon";
GRANT ALL ON TABLE "public"."ql_baocao" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_baocao" TO "service_role";


--
-- Name: TABLE "ql_nop_bc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ql_nop_bc" TO "anon";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "authenticated";
GRANT ALL ON TABLE "public"."ql_nop_bc" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "theodoi360"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."theodoi360" TO "anon";
GRANT ALL ON TABLE "public"."theodoi360" TO "authenticated";
GRANT ALL ON TABLE "public"."theodoi360" TO "service_role";


--
-- Name: TABLE "thongbao_hethong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_hethong" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_hethong" TO "service_role";


--
-- Name: TABLE "thongbao_riengbiet"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "anon";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "authenticated";
GRANT ALL ON TABLE "public"."thongbao_riengbiet" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "vanban_doan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."vanban_doan" TO "anon";
GRANT ALL ON TABLE "public"."vanban_doan" TO "authenticated";
GRANT ALL ON TABLE "public"."vanban_doan" TO "service_role";


--
-- Name: TABLE "xet_thidua"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."xet_thidua" TO "anon";
GRANT ALL ON TABLE "public"."xet_thidua" TO "authenticated";
GRANT ALL ON TABLE "public"."xet_thidua" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_08_16"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_16" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_17"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_17" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_18"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_18" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_19"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_19" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_20"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_20" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_21"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_21" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_21" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_08_22"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_08_22" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_08_22" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict ArlJQfdEJb4R9RV26SCFRKbBkvdAbL7JeMKmKkNkpZKsRqcIofMi3MiA9Dkc19K

